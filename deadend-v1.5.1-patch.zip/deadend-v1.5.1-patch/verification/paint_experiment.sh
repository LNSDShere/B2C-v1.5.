#!/bin/bash
# canvas-paint verification: paint, wipe, save png
set -u
export DEP_SYSROOT=/home/z/.x11sysroot
export LD_LIBRARY_PATH=/home/z/.x11bin/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}
XDOT=/home/z/.x11bin/usr/bin/xdotool
SHOT="python3 /home/z/my-project/scripts/xshot.py"
DEC=/home/z/my-project/b2c/extracted/deadend-protocol-v1.5.0/dec
export DISPLAY=:66

pkill -f "Xvfb" 2>/dev/null; sleep 0.8
rm -f /tmp/.X11-unix/X* /tmp/.X*-lock 2>/dev/null
Xvfb :66 -screen 0 640x480x24 > /tmp/probe/xvfb6.log 2>&1 &
XPID=$!
sleep 2

cd /home/z/my-project/b2c/extracted/deadend-protocol-v1.5.0
rm -f painting.png
DEP_FRAMES=560 timeout 90 "$DEC" run examples/canvas-paint.dep > /tmp/probe/paint.log 2>&1 &
PROG_PID=$!
sleep 4.5

# paint a smiley-ish curve
$XDOT mousemove 150 250 sleep 0.2
$XDOT mousedown 1
for p in "200 280" "260 300" "320 300" "380 280" "430 250"; do
  $XDOT mousemove $p sleep 0.12
done
$XDOT mouseup 1 sleep 0.3
# wheel up twice -> bigger brush, paint a dot
$XDOT click 4 sleep 0.2; $XDOT click 4 sleep 0.2
$XDOT mousemove 300 180 sleep 0.2
$XDOT mousedown 1 sleep 0.3; $XDOT mouseup 1 sleep 0.3
$SHOT :66 /tmp/probe/paint_live.png
# save it
$XDOT keydown s sleep 0.2; $XDOT keyup s sleep 0.6

wait $PROG_PID
kill $XPID 2>/dev/null
echo "=== paint.log ==="
cat /tmp/probe/paint.log
ls -la painting.png 2>&1
