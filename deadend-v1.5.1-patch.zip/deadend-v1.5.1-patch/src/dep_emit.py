"""DeadEnd analyzer + C emitter.

Pipeline: AST -> analysis (names, kits, function table, type inference)
              -> C source (transpiled, refcount-correct, typed locals).

Type lattice: 'num' 'text' 'bool' 'list' 'map' 'unk' 'void'
  'unk' compiles to a boxed DEPValue; everything else to a bare C type,
  which is what makes numeric code run at C speed.
"""
from dep_parse import DepError

# ---------------------------------------------------------------- builtins
# spec: arg string of 'n' (number) / 't' (text) / 'a' (any); ret type; c func
BUILTIN_DEFS = [
    ("ask", ("t",), "text", "dep_ask2"),
    ("clock", (), "num", "dep_clock"),
    ("random", ("n", "n"), "num", "dep_random"),
    ("random", ("n",), "num", "dep_random1"),
    ("abs", ("n",), "num", "fabs"),
    ("floor", ("n",), "num", "floor"),
    ("ceiling", ("n",), "num", "ceil"),
    ("round", ("n",), "num", "round"),
    ("sqrt", ("n",), "num", "sqrt"),
    ("sin", ("n",), "num", "sin"),
    ("cos", ("n",), "num", "cos"),
    ("tan", ("n",), "num", "tan"),
    ("atan", ("n",), "num", "atan"),
    ("power", ("n", "n"), "num", "pow"),
    ("min", ("n", "n"), "num", "fmin"),
    ("max", ("n", "n"), "num", "fmax"),
    ("text", ("a",), "text", "dep_text2"),
    ("number", ("a",), "unk", "dep_number2"),
    ("upper", ("t",), "text", "dep_upper2"),
    ("lower", ("t",), "text", "dep_lower2"),
    ("trim", ("t",), "text", "dep_trim2"),
    ("split", ("t", "t"), "list", "dep_split2"),
    ("join", ("a", "t"), "text", "dep_join2"),
    ("find", ("a", "a"), "num", "dep_find2"),
    ("replace", ("t", "t", "t"), "text", "dep_replace2"),
    ("count", ("a",), "num", "dep_count_of"),
    ("keys", ("a",), "list", "dep_keys_of"),
    ("first", ("a",), "unk", "dep_first_of"),
    ("last", ("a",), "unk", "dep_last_of"),
    ("load", ("t",), "unk", "dep_load2"),
    ("save", ("t", "a"), "void", "dep_save2"),
    ("exists", ("t",), "bool", "dep_exists2"),
    ("sort", ("a",), "void", "dep_sort2"),
    ("reverse", ("a",), "void", "dep_reverse2"),
    ("shuffle", ("a",), "void", "dep_shuffle2"),
    ("title", ("t",), "void", "dep_set_title"),
    # game kit
    ("holding", ("t",), "bool", "dep_g_holding"),
    ("pressed", ("t",), "bool", "dep_g_pressed"),
    ("clear", ("t",), "void", "dep_g_clear"),
    ("pixel", ("n", "n", "t"), "void", "dep_g_pixel"),
    ("line", ("n", "n", "n", "n", "t"), "void", "dep_g_line"),
    ("box", ("n", "n", "n", "n", "t"), "void", "dep_g_box"),
    ("circle", ("n", "n", "n", "t"), "void", "dep_g_circle"),
    ("ring", ("n", "n", "n", "t"), "void", "dep_g_ring"),
    ("write", ("a", "n", "n", "n", "t"), "void", "dep_g_write"),
    ("image", ("t", "n", "n"), "void", "dep_g_image3"),
    ("image", ("t", "n", "n", "n", "n"), "void", "dep_g_image5"),
    ("sound", ("t",), "void", "dep_g_sound"),
    ("music", ("t",), "void", "dep_g_music"),
    ("silence", (), "void", "dep_g_silence"),
    ("time", (), "num", "dep_g_time"),
    ("delta", (), "num", "dep_g_delta"),
    # app kit
    ("field", ("t",), "text", "dep_a_field"),
    ("checkbox", ("t",), "bool", "dep_a_checkbox"),
    ("slider", ("t",), "num", "dep_a_slider"),
    ("label", ("t",), "text", "dep_a_label"),
    # motion kit (v1.4.0)
    ("moving", ("a",), "bool", "dep_m_moving_v"),
    ("playing", ("t",), "bool", "dep_m_tl_playing_v"),
    ("finished", ("t",), "bool", "dep_m_tl_finished_v"),
    ("particles", (), "num", "dep_m_particle_count_v"),
    ("ease", ("a", "a"), "num", "dep_m_ease_call"),
]

BUILTINS = {}          # (name, argc) -> (argspec, ret, cfunc)
BUILTIN_NAMES = {}     # name -> min argc set (for errors)
for _n, _a, _r, _c in BUILTIN_DEFS:
    BUILTINS[(_n, len(_a))] = (_a, _r, _c)
    BUILTIN_NAMES.setdefault(_n, set()).add(len(_a))

OF_FORMS = {"count", "keys", "first", "last"}   # also usable as `count of x`

WIDGETS = {"title": 0, "label": 1, "button": 2, "field": 3, "checkbox": 4,
           "slider": 5, "image": 6, "panel": 7}


def join(a, b):
    if a == b:
        return a
    if a is None:
        return b
    if b is None:
        return a
    return "unk"


CTYPE = {"num": "double", "text": "DEPStr *", "bool": "int",
         "list": "DEPList *", "map": "DEPMap *", "unk": "DEPValue"}


def c_str(s):
    r"""C string literal from a Python string, byte-exact for any UTF-8 text.
    Non-ASCII bytes use 3-digit octal escapes (never \x, which swallows
    following hex-looking characters), so unicode survives the round trip."""
    out = ['"']
    for byte in s.encode("utf-8"):
        ch = chr(byte)
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\t":
            out.append("\\t")
        elif ch == "\r":
            out.append("\\r")
        elif byte == 0:
            out.append("\\000")
        elif 32 <= byte < 127:
            out.append(ch)
        else:
            out.append(f"\\{byte:03o}")
    out.append('"')
    return "".join(out)


def c_num(x):
    r = repr(x)
    return r


class FnInfo:
    def __init__(self, name, params, body, line):
        self.name = name
        self.params = params
        self.body = body
        self.line = line
        self.ptypes = {p: "num" for p in params}
        self.ret = "num"
        self.calls = []          # [(argnodes, line, caller_fn)]
        self.ret_nodes = []      # [node or None]
        self.locals = {}         # name -> [assign exprs]
        self.reads_before = {}   # name -> first-is-read (bool)


class Compiler:
    def __init__(self, ast):
        self.ast = ast
        self.kit = None               # 'game' | 'app'
        self.fns = {}                 # name -> FnInfo
        self.globals = {}             # name -> [assign exprs]
        self.global_reads_before = {}
        self.handlers = []            # [('game_starts'|'frame'|'button', arg, body, line)]
        self.make = None              # last make node
        self.strlits = {}
        self.gtypes = {}
        self.tmp = 0
        self.btn_count = 0
        # motion kit (v1.4.0)
        self.motion_slots = {}        # "dot.x" -> slot id
        self.motion_ranges = {}       # "dot" -> (lo, hi) slot ids
        self.motion_binds = []        # [(sid, base, chain, last, gtype)]
        self.motion_next = 1          # slot 0 reserved: never animates
        # bug fix (40): a program that registers game/app handlers but never
        # writes `run game` / `run app` used to compile into a program that
        # exits instantly with no window and no message
        self.ran = {"game": False, "app": False}
        self.saw_frame = False        # an `every frame` handler exists
        self.saw_start = False        # a `when game starts` handler exists
        self.saw_click = False        # a `when "btn" clicked` handler exists
        self.saw_widget = False       # an `add ...` widget call exists

    # ================= analysis =================
    def _walk_stmts(self, stmts):
        """Yield every statement, descending into all nested bodies."""
        for st in stmts:
            yield st
            k = st[0]
            if k == "if":
                for c, b in st[1]:
                    yield from self._walk_stmts(b)
                yield from self._walk_stmts(st[2])
            elif k in ("repeat_n",):
                yield from self._walk_stmts(st[2])
            elif k == "repeat_for":
                yield from self._walk_stmts(st[5])
            elif k == "repeat_forever":
                yield from self._walk_stmts(st[1])
            elif k == "while":
                yield from self._walk_stmts(st[2])
            elif k == "foreach":
                yield from self._walk_stmts(st[3])
            elif k == "func":
                yield from self._walk_stmts(st[3])
            elif k == "when":
                yield from self._walk_stmts(st[3])
            elif k == "every":
                yield from self._walk_stmts(st[1])
            elif k == "canvas_paint":
                yield from self._walk_stmts(st[2])
            elif k == "everytime":
                yield from self._walk_stmts(st[3])

    def analyze(self):
        # pass 1: top-level structure
        main_body = []
        for st in self.ast:
            k = st[0]
            if k == "use":
                if self.kit and self.kit != st[1]:
                    raise DepError("use only one kit per program for now "
                                   "(game kit or app kit)", 0)
                self.kit = st[1]
            elif k == "func":
                name, params, body, line = st[1], st[2], st[3], st[4]
                if name in self.fns:
                    raise DepError(f"there is already a function called {name}", line)
                if name in BUILTIN_NAMES:
                    raise DepError(f"'{name}' is a built-in word; pick another "
                                   f"name for your function", line)
                if len(set(params)) != len(params):
                    raise DepError(f"function {name} uses the same parameter "
                                   f"name twice", line)
                self.fns[name] = FnInfo(name, params, body, line)
            elif k in ("when", "every"):
                if k == "every":
                    self.handlers.append(("frame", None, st[1], st[2]))
                else:
                    self.handlers.append((st[1], st[2], st[3], st[4]))
                main_body.append(st)   # keep position for registration
            elif k == "make":
                self.make = st
                main_body.append(st)
            else:
                main_body.append(st)
        self.main_body = main_body

        # kit checks
        for st in self.ast:
            k, line = st[0], st[-1] if isinstance(st[-1], int) else 0
            needs_game = k in ("every", "mfx", "mpart")
            needs_app = k in ("addwidget", "setwidget", "mui")
            if k == "when":
                needs_app = st[1] == "button"
                needs_game = st[1] == "game_starts"
            if k == "run":
                needs_game = st[1] == "game"
                needs_app = st[1] == "app"
            if needs_game and self.kit != "game":
                raise DepError(f"this needs 'use game kit' at the top of your "
                               f"program", line)
            if needs_app and self.kit != "app":
                raise DepError(f"this needs 'use app kit' at the top of your "
                               f"program", line)
        # canvas/camera/timer sentences can sit deep inside blocks -- scan
        # every statement tree for them (v1.5.1)
        KIT_MSG = {
            "canvas_paint": "'paint on canvas'",
            "canvas_show": "'show canvas'",
            "canvas_clear": "'clear canvas'",
            "canvas_save": "'save canvas'",
            "cam_pan": "'pan camera'",
            "cam_follow": "'follow camera'",
            "cam_release": "'release camera'",
            "everytime": "'every N seconds'",
        }
        for st in self._walk_stmts(self.ast):
            k = st[0]
            if k in KIT_MSG and self.kit != "game":
                line = st[-1] if isinstance(st[-1], int) else 0
                raise DepError(f"{KIT_MSG[k]} needs 'use game kit' at the "
                               f"top of your program", line)

        # globals: assignments at top level (outside functions/handlers)
        self._collect_assigns(self.main_body, self.globals, self.global_reads_before)

        # per-function locals + call/return collection
        for fn in self.fns.values():
            self._collect_fn(fn)
        self.handlers_by = {}
        for kind, arg, body, line in self.handlers:
            h = FnInfo(f"__handler_{line}", [], body, line)
            for r in h.ret_nodes:
                pass
            key = (kind, arg)
            if key in self.handlers_by:
                what = "every frame" if kind == "frame" else \
                    f"when game starts" if kind == "game_starts" else \
                    f"when button \"{arg}\" is clicked"
                raise DepError(f"two '{what}' blocks -- a program can have only "
                               f"one of each", line)
            # handlers give no value back
            self._collect_fn(h)
            h.ret = "void"
            for r in h.ret_nodes:
                if r is not None:
                    raise DepError("blocks like 'when game starts' and 'every "
                                   "frame' cannot return values", line)
            self.handlers_by[key] = h

        # param/return fixpoint
        for _ in range(4):
            changed = False
            # record call sites that appear at the top level (main body)
            for st in self.main_body:
                if st[0] == "callstmt":
                    self.inf(("call", st[1], st[2], st[3]), None)
                for node in self._walk_nodes(st):
                    self.inf(node, None)
            # record call sites inside handlers too
            for h in self.handlers_by.values():
                for st in h.body:
                    if st[0] == "callstmt":
                        self.inf(("call", st[1], st[2], st[3]), h)
                    for node in self._walk_nodes(st):
                        self.inf(node, h)
            for fn in self.fns.values():
                for argnodes, line, caller in fn.calls:
                    for i, a in enumerate(argnodes):
                        t = self.inf(a, caller)
                        new = join(fn.ptypes.get(fn.params[i]), t)
                        if new != fn.ptypes[fn.params[i]]:
                            fn.ptypes[fn.params[i]] = new
                            changed = True
                newret = None
                for r in fn.ret_nodes:
                    newret = join(newret, "unk" if r is None else self.inf(r, fn))
                if not fn.ret_nodes:
                    newret = "void"
                newret = "void" if newret is None else newret
                if newret != fn.ret:
                    fn.ret = newret
                    changed = True
            if not changed:
                break

        # global var types (fixpoint: self-references like `set x to x + 1`)
        self.gtypes = {}
        for name in self.globals:
            self.gtypes[name] = "num"
        for _ in range(5):
            changed = False
            for name, exprs in self.globals.items():
                t = None
                for e in exprs:
                    it = self.inf_top(e)
                    if it == "void":
                        continue      # a void call is an emit-time error
                    t = join(t, it)
                t = t or "unk"
                if t != self.gtypes[name]:
                    self.gtypes[name] = t
                    changed = True
            if not changed:
                break

        # collect string literals
        self._collect_strlits()

        # motion kit: pre-allocate one slot per animated target so 'moving x.y'
        # queries resolve no matter where they appear in the program
        self._prescan_motion(self.main_body)
        for fn in self.fns.values():
            self._prescan_motion(fn.body)
        for h in self.handlers_by.values():
            self._prescan_motion(h.body)
        # ...and pre-register the word literals that compile to DEPValue
        # (feel words, colors, slide directions, particle kinds)
        self._register_motion_literals(self.main_body)
        for fn in self.fns.values():
            self._register_motion_literals(fn.body)
        for h in self.handlers_by.values():
            self._register_motion_literals(h.body)

    # ---------------- motion kit ----------------
    MOTION_OPT_EXPRS = ("dur", "from_expr", "delay", "repeat",
                        "speed", "wobble", "stiffness", "damping",
                        "x", "y", "strength", "target")

    def _target_parts(self, tgt):
        """('tfield', ('tname', 'dot'), 'x') -> ('dot', [], 'x')."""
        parts = []
        node = tgt
        while node[0] == "tfield":
            parts.append(node[2])
            node = node[1]
        if node[0] != "tname":
            return None
        parts.append(node[1])
        parts.reverse()
        if len(parts) == 1:
            return parts[0], [], None
        return parts[0], parts[1:-1], parts[-1]

    def _slot_key(self, tgt):
        base, chain, last = self._target_parts(tgt)
        if last is None:
            return base
        return base + "." + ".".join(chain + [last])

    def _alloc_slot(self, tgt, line):
        parts = self._target_parts(tgt)
        if parts is None:
            raise DepError("animations need a target like score or dot.x", line)
        base, chain, last = parts
        if base == "mouse":
            raise DepError("'mouse' belongs to the game kit and cannot be "
                           "animated", line)
        if base not in self.globals:
            raise DepError(f"animations need a GLOBAL variable so they can "
                           f"keep moving between frames -- '{base}' is not "
                           f"one (create it at the top of your program with "
                           f"'set {base} to ...')", line)
        gt = self.gtypes.get(base, "unk")
        if last is None:
            key = base
            if gt not in ("num", "bool", "unk"):
                raise DepError(f"only number variables can be animated "
                               f"('{base}' holds {gt})", line)
        else:
            key = base + "." + ".".join(chain + [last])
            if gt not in ("map", "unk"):
                raise DepError(f"'{base}' is not a map, so '{base}.{last}' "
                               f"cannot be animated", line)
        if key in self.motion_slots:
            return self.motion_slots[key]
        sid = self.motion_next
        self.motion_next += 1
        self.motion_slots[key] = sid
        lo, hi = self.motion_ranges.get(base, (None, None))
        self.motion_ranges[base] = (sid if lo is None else lo, sid)
        self.motion_binds.append((sid, base, list(chain), last, gt))
        return sid

    def _motion_fields(self, target, value, line):
        """`move dot toward {x: 100, y: 50}` animates one slot per field.
        Returns [(field_name, value_expr), ...] when value is a map literal,
        or None for plain single-number moves."""
        if value is None or value[0] != "map":
            return None
        fields = []
        for kexpr, vexpr in value[1]:
            if kexpr[0] != "text":
                raise DepError("when moving a map, write plain field names, "
                               "like: move dot toward {x: 100, y: 50}", line)
            fields.append((kexpr[1], vexpr))
        if not fields:
            raise DepError("the map to move needs at least one field, like "
                           "{x: 100, y: 50}", line)
        if target is None or self._target_parts(target) is None:
            raise DepError("animations need a target like score or dot.x",
                           line)
        return fields

    def _alloc_motion(self, target, value, line):
        fields = self._motion_fields(target, value, line)
        if fields is None:
            self._alloc_slot(target, line)
            return
        for fname, _v in fields:
            self._alloc_slot(("tfield", target, fname), line)

    def _spring_codes(self, opts, fn):
        """map feel knobs (speed / wobble / stiffness / damping -- or a
        `lasting N seconds` duration) to C code."""
        if opts["stiffness"] is not None:
            stiff = self._num_expr(opts["stiffness"], fn)
        elif opts["speed"] is not None:
            sv = self._num_expr(opts["speed"], fn)
            stiff = f"(170.0 * ({sv}) * ({sv}))"
        elif opts["dur"] is not None:
            # `spring x toward 80 lasting 2 seconds` -- try to settle in
            # about that long: speed ~= 1/duration
            dv = self._motion_duration(opts, "dur", "1.0")
            stiff = f"(170.0 / ({dv} * {dv}))"
        else:
            stiff = "170.0"
        if opts["damping"] is not None:
            damp = self._num_expr(opts["damping"], fn)
        else:
            wv = (self._num_expr(opts["wobble"], fn)
                  if opts["wobble"] is not None else "2.0")
            damp = f"(2.0 * (1.0 / (1.0 + 0.25 * ({wv}))) * sqrt({stiff}))"
        return stiff, damp

    def _prescan_motion(self, stmts):
        for st in stmts:
            k = st[0]
            if k in ("mmove", "mspring"):
                self._alloc_motion(st[1], st[2], st[-1])
            elif k == "mtl_add":
                inner = st[2]
                if inner[0] in ("mmove", "mspring"):
                    self._alloc_motion(inner[1], inner[2], inner[-1])
            elif k == "if":
                for c, b in st[1]:
                    self._prescan_motion(b)
                self._prescan_motion(st[2])
            elif k == "repeat_n":
                self._prescan_motion(st[2])
            elif k == "repeat_for":
                self._prescan_motion(st[5])
            elif k == "repeat_forever":
                self._prescan_motion(st[1])
            elif k == "while":
                self._prescan_motion(st[2])
            elif k == "canvas_paint":
                self._prescan_motion(st[2])
            elif k == "everytime":
                self._prescan_motion(st[3])

    def _lit_code(self, s):
        """emit an owned DEPValue holding a compile-time word"""
        slot = self.strlits.setdefault(s, f"SL_{len(self.strlits)}")
        return f"dep_vs(dep_lit(&{slot}, {c_str(s)}))"

    def _register_motion_literals(self, stmts):
        """ensure every motion word that becomes a DEPValue has a strlit slot
        declared before use (slots are declared right after analyze)."""
        def reg(*words):
            for w in words:
                if w:
                    self.strlits.setdefault(w, f"SL_{len(self.strlits)}")
        for st in stmts:
            k = st[0]
            if k in ("mmove", "mspring"):
                pass                                  # feel goes as const char*
            elif k == "mtl_add":
                inner = st[2]
                if inner[0] == "mui":
                    o = inner[4]
                    reg(o.get("feel"), o.get("dir"))
            elif k == "mui":
                o = st[4]
                reg(o.get("feel"), o.get("dir"))
            elif k == "mfx":
                o = st[2]
                if isinstance(o.get("color"), tuple):
                    reg(o["color"][1])
                reg(o.get("feel"))
            elif k == "mpart" and st[1] != "clear":
                opts = st[2][4] if st[1] == "burst" else st[2][1]
                if isinstance(opts.get("color"), tuple):
                    reg(opts["color"][1])
                if st[1] == "burst":
                    reg(st[2][1])
            elif k == "if":
                for c, b in st[1]:
                    self._register_motion_literals(b)
                self._register_motion_literals(st[2])
            elif k == "repeat_n":
                self._register_motion_literals(st[2])
            elif k == "repeat_for":
                self._register_motion_literals(st[5])
            elif k == "repeat_forever":
                self._register_motion_literals(st[1])
            elif k == "while":
                self._register_motion_literals(st[2])

    def _num_expr(self, node, fn):
        c, t = self.emit_expr(node, fn)
        return c if t == "num" else f"dep_as_num({self.own_of(c, t)})"

    def _motion_duration(self, opts, key, default):
        e = opts.get(key)
        if e is None:
            return default
        v = self._num_expr(e, None)
        if opts.get(key.replace("dur", "dur_ms").replace("delay", "delay_ms")):
            return f"({v} / 1000.0)"
        return f"({v})"

    def _collect_assigns(self, stmts, table, reads_before, fn=None):
        """Record assignments (recursing into blocks); note first-use-as-read."""

        def walk(stmts):
            for st in stmts:
                k = st[0]
                if k == "set":
                    base = st[1]
                    while base[0] != "tname":
                        base = base[1]
                    if fn and (base[1] in self.globals or base[1] in fn.params):
                        pass
                    else:
                        table.setdefault(base[1], []).append(st[2])
                elif k == "change":
                    base = st[1]
                    while base[0] != "tname":
                        base = base[1]
                    if fn and (base[1] in self.globals or base[1] in fn.params):
                        pass
                    else:
                        table.setdefault(base[1], []).append(
                            ("bin", "+", self._target_read(st[1]), st[2]))
                elif k == "repeat_for":
                    if fn and (st[1] in self.globals or st[1] in fn.params):
                        pass
                    else:
                        table.setdefault(st[1], []).append(("num", 0))
                    walk(st[5])                   # assignments in the body too
                elif k == "foreach":
                    if fn and (st[1] in self.globals or st[1] in fn.params):
                        pass
                    else:
                        table.setdefault(st[1], []).append(("unk",))
                    walk(st[3])                   # assignments in the body too
                elif k == "if":
                    for c, b in st[1]:
                        walk(b)
                    walk(st[2])
                elif k == "repeat_n":
                    walk(st[2])
                elif k == "repeat_forever":
                    walk(st[1])
                elif k == "while":
                    walk(st[2])
                elif k == "canvas_paint":
                    walk(st[2])
                elif k == "everytime":
                    walk(st[3])

        walk(stmts)

        # read-before-write sweep in source order
        seen_writes = set()

        def sweep(stmts):
            for st in stmts:
                for nm, is_read in self._reads_of(st):
                    if is_read:
                        if nm not in seen_writes and not reads_before.get(nm):
                            reads_before[nm] = True
                    elif nm not in seen_writes:
                        seen_writes.add(nm)
                k = st[0]
                if k == "if":
                    for c, b in st[1]:
                        sweep(b)
                    sweep(st[2])
                elif k in ("repeat_n",):
                    sweep(st[2])
                elif k == "repeat_for":
                    seen_writes.add(st[1])
                    sweep(st[5])
                elif k == "repeat_forever":
                    sweep(st[1])
                elif k == "while":
                    sweep(st[2])
                elif k == "foreach":
                    seen_writes.add(st[1])
                    sweep(st[3])
                elif k == "canvas_paint":
                    sweep(st[2])
                elif k == "everytime":
                    sweep(st[3])
        sweep(stmts)

    def _base_name(self, tgt):
        while tgt[0] != "tname":
            tgt = tgt[1]
        return tgt[1]

    def _target_read(self, tgt):
        if tgt[0] == "tname":
            return ("name", tgt[1])
        if tgt[0] == "tfield":
            return ("field", self._target_read(tgt[1]), tgt[2])
        return ("index", self._target_read(tgt[1]), tgt[2])

    def _container_of(self, tgt, fn):
        """Emit an owned DEPValue for the container a set/add/remove target
        refers to. A bare name yields the variable itself; a field or index
        target yields the *inner* list/map (maps and lists are reference
        types, so mutating through dep_field2/dep_index2 changes the stored
        value in place -- the same rule 'set hero.x to ...' already uses)."""
        if tgt[0] == "tname":
            return self.emit_expr(("name", tgt[1]), fn)
        if tgt[0] == "tfield":
            bc, bt = self._container_of(tgt[1], fn)
            return f'dep_field2({self.own_of(bc, bt)}, {c_str(tgt[2])})', "unk"
        bc, bt = self._container_of(tgt[1], fn)
        ic, it = self.emit_expr(tgt[2], fn)
        return f'dep_index2({self.own_of(bc, bt)}, {self.own_of(ic, it)})', "unk"

    def _walk_nodes(self, st):
        """Yield expression nodes appearing in statement st."""
        k = st[0]
        if k == "set":
            yield st[2]
            if st[1][0] == "tindex":
                yield st[1][2]
        elif k == "change":
            yield st[2]
        elif k == "print":
            yield from st[1]
        elif k == "if":
            for c, b in st[1]:
                yield c
                for s2 in b:
                    yield from self._walk_nodes(s2)
            for s2 in st[2]:
                yield from self._walk_nodes(s2)
        elif k == "repeat_n":
            yield st[1]
            for s2 in st[2]:
                yield from self._walk_nodes(s2)
        elif k == "repeat_for":
            yield from (st[2], st[3])
            if st[4]:
                yield st[4]
            for s2 in st[5]:
                yield from self._walk_nodes(s2)
        elif k == "repeat_forever":
            for s2 in st[1]:
                yield from self._walk_nodes(s2)
        elif k == "while":
            yield st[1]
            for s2 in st[2]:
                yield from self._walk_nodes(s2)
        elif k == "foreach":
            yield st[2]
            for s2 in st[3]:
                yield from self._walk_nodes(s2)
        elif k == "return":
            if st[1] is not None:
                yield st[1]
        elif k == "callstmt":
            yield from st[2]
            if len(st) > 4 and st[4]:
                for v in st[4].values():
                    if v is True:
                        continue
                    for e in v:            # each clause value is a tuple of nodes
                        if isinstance(e, tuple):
                            yield e
        elif k == "make":
            yield st[2]
            for e in st[3].values():
                yield e
        elif k == "append":
            yield self._target_read(st[1]) if hasattr(self, '_target_read') else st[1]
            yield st[2]
        elif k == "remove":
            yield st[2]
        elif k == "canvas_paint":
            for s2 in st[2]:
                yield from self._walk_nodes(s2)
        elif k == "canvas_show":
            yield st[1]
            for e in st[2:6]:
                if e is not None:
                    yield e
        elif k in ("canvas_clear", "canvas_save"):
            yield st[1]
            yield st[2]
        elif k == "cam_pan":
            yield st[2]
            yield st[3]
            if st[4] is not None:
                yield st[4]
        elif k == "cam_follow":
            yield st[1]
            yield st[2]
            if st[3] is not None:
                yield st[3]
        elif k == "everytime":
            yield st[1]
            for s2 in st[3]:
                yield from self._walk_nodes(s2)
        elif k == "addwidget":
            yield from (st[3], st[4])
            if st[5]:
                yield st[5]
            if st[6]:
                yield st[6]
        elif k == "setwidget":
            yield st[3]
        elif k in ("mmove", "mspring"):
            yield st[2]
            for key in self.MOTION_OPT_EXPRS:
                e = st[3].get(key)
                if e is not None:
                    yield e
        elif k == "mtl_add":
            inner = st[2]
            if inner[0] in ("mmove", "mspring"):
                yield inner[2]
                for key in self.MOTION_OPT_EXPRS:
                    e = inner[3].get(key)
                    if e is not None:
                        yield e
            elif inner[0] == "mui":
                for key in ("dur", "x", "y", "strength"):
                    e = inner[4].get(key)
                    if e is not None:
                        yield e
            elif inner[0] == "mwait":
                yield inner[1]
        elif k == "mui":
            for key in ("dur", "x", "y", "strength"):
                e = st[4].get(key)
                if e is not None:
                    yield e
        elif k == "mwait":
            yield st[1]
        elif k == "mfx":
            for key in ("color", "target", "dur", "strength"):
                e = st[2].get(key)
                if e is not None:
                    yield e
        elif k == "mpart":
            op, payload = st[1], st[2]
            if op == "clear":
                return
            if op == "burst":
                n, kind, x, y, o = payload
                yield from (n, x, y)
                opts = o
            else:
                n, opts = payload
                yield n
            for key in ("color", "speed", "size", "life"):
                e = opts.get(key)
                if e is not None:
                    yield e
        elif k == "madvance":
            yield st[1]
        elif k == "mtl_play":
            if st[2] is not None:
                yield st[2]

    def _reads_of(self, st):
        """(name, is_read) pairs in source order for first-use analysis."""
        out = []

        def rn(node):
            k = node[0]
            if k == "name":
                out.append((node[1], True))
            elif k == "field":
                rn(node[1])
            elif k == "index":
                rn(node[1])
                rn(node[2])
            elif k == "list":
                for e in node[1]:
                    rn(e)
            elif k == "map":
                for kk, vv in node[1]:
                    rn(vv)
            elif k == "call":
                for a in node[2]:
                    rn(a)
            elif k == "bin":
                rn(node[2])
                rn(node[3])
            elif k == "un":
                rn(node[2])
            elif k == "cmp":
                rn(node[2])
                rn(node[3])
            elif k in ("is", "isnot", "has", "hasnot"):
                rn(node[1])
                rn(node[2])
        for node in self._walk_nodes(st):
            rn(node)
        # writes
        k = st[0]
        if k == "set" or k == "change":
            base = st[1]
            while base[0] != "tname":
                # indices in target are reads
                if base[0] == "tindex":
                    rn(base[2])
                base = base[1]
            out.append((base[1], False))
        return out

    def _collect_fn(self, fn):
        def collect(stmts):
            for st in stmts:
                k = st[0]
                if k in ("set", "change"):
                    base = st[1]
                    while base[0] != "tname":
                        base = base[1]
                    name = base[1]
                    if name not in self.globals and name not in fn.params:
                        if k == "change":
                            fn.locals.setdefault(name, []).append(
                                ("bin", "+", ("name", name), st[2]))
                        else:
                            fn.locals.setdefault(name, []).append(st[2])
                elif k == "repeat_for":
                    if st[1] not in self.globals and st[1] not in fn.params:
                        fn.locals.setdefault(st[1], []).append(("num", 0))
                elif k == "foreach":
                    if st[1] not in self.globals and st[1] not in fn.params:
                        fn.locals.setdefault(st[1], []).append(("unk",))
                elif k == "return":
                    fn.ret_nodes.append(st[1])
                    if st[1] is not None:
                        pass
                elif k == "callstmt":
                    name, args, line = st[1], st[2], st[3]
                    if name in self.fns:
                        f = self.fns[name]
                        if len(args) != len(f.params):
                            raise DepError(
                                f"{name} takes {len(f.params)} value(s) "
                                f"({', '.join(f.params) or 'none'}) but got "
                                f"{len(args)}", line)
                        f.calls.append((args, line, fn))
                    elif (name, len(args)) in BUILTINS or (name, 0) in BUILTINS and not args:
                        pass
                    elif name not in BUILTIN_NAMES and name not in self.fns:
                        raise DepError(f"I don't know a function called "
                                       f"'{name}'", line)
                    elif name in BUILTIN_NAMES and len(args) not in BUILTIN_NAMES[name]:
                        raise DepError(f"{name} takes "
                                       f"{' or '.join(str(n) for n in sorted(BUILTIN_NAMES[name]))} "
                                       f"value(s) but got {len(args)}", line)
                # recurse
                if k == "if":
                    for c, b in st[1]:
                        collect(b)
                    collect(st[2])
                elif k == "repeat_n":
                    collect(st[2])
                elif k == "repeat_for":
                    collect(st[5])
                elif k == "repeat_forever":
                    collect(st[1])
                elif k == "while":
                    collect(st[2])
                elif k == "foreach":
                    collect(st[3])
                elif k == "func":
                    raise DepError("define functions at the top level, not "
                                   "inside other functions", st[4])
                elif k in ("use", "make", "when", "every", "run"):
                    raise DepError(f"'{k}' can only be used at the top level of "
                                   f"your program", 0)

        collect(fn.body)
        self._collect_assigns(fn.body, fn.locals,
                              fn.reads_before, fn=fn)
        # functions/handlers cannot read main's locals (only globals)
        fn.local_types = {n: "num" for n in fn.locals}
        for _ in range(4):
            changed = False
            for name, exprs in fn.locals.items():
                t = None
                for e in exprs:
                    it = self.inf(e, fn)
                    if it == "void":
                        continue      # a void call is an emit-time error
                    t = join(t, it)
                t = t or "unk"
                if t != fn.local_types[name]:
                    fn.local_types[name] = t
                    changed = True
            if not changed:
                break

    # ================= inference =================
    def inf(self, node, fn):
        k = node[0]
        if k == "num":
            return "num"
        if k == "text":
            return "text"
        if k == "bool":
            return "bool"
        if k == "nothing":
            return "unk"
        if k == "list":
            return "list"
        if k == "map":
            return "map"
        if k == "name":
            n = node[1]
            if fn and n in fn.params:
                return fn.ptypes[n]
            if fn and n in fn.locals:
                return fn.local_types.get(n, "unk")
            if n in self.globals:
                return self.gtypes.get(n, "unk")
            if n == "mouse" and self.kit == "game":
                return "map"
            if (n, 0) in BUILTINS:
                return BUILTINS[(n, 0)][1]
            if n in self.fns and not self.fns[n].params:
                return self.fns[n].ret
            if n in BUILTIN_NAMES:
                raise DepError(f"'{n}' is a built-in word, so it cannot be used "
                               f"as a name here", 0)
            raise DepError(f"'{n}' has no value (set it first, or check the "
                           f"spelling)", node[2] if len(node) > 2 else 0)
        if k in ("field", "index"):
            return "unk"
        if k == "call":
            name, args = node[1], node[2]
            if name in self.fns:
                f = self.fns[name]
                if len(args) != len(f.params):
                    raise DepError(f"{name} takes {len(f.params)} value(s) "
                                   f"({', '.join(f.params) or 'none'}) but got "
                                   f"{len(args)}", node[3])
                f.calls.append((args, node[3], fn))
                return f.ret
            key = (name, len(args))
            if key in BUILTINS:
                return BUILTINS[key][1]
            if name in BUILTIN_NAMES:
                raise DepError(f"{name} takes "
                               f"{' or '.join(str(n) for n in sorted(BUILTIN_NAMES[name]))} "
                               f"value(s) but got {len(args)}", node[3])
            raise DepError(f"I don't know a function called '{name}'", node[3])
        if k == "bin":
            op = node[1]
            t1 = self.inf(node[2], fn)
            t2 = self.inf(node[3], fn)
            if op == "+":
                if t1 == "num" and t2 == "num":
                    return "num"
                if t1 == "text" or t2 == "text":
                    return "text"
                return "unk"
            if op in ("-", "*", "/", "%"):
                return "num" if (t1 == "num" and t2 == "num") else "unk"
            if op in ("and", "or"):
                return "bool" if (t1 == "bool" and t2 == "bool") else "unk"
        if k == "un":
            if node[1] == "neg":
                return "num" if self.inf(node[2], fn) == "num" else "unk"
            return "bool"
        if k in ("is", "isnot", "cmp", "has", "hasnot", "hits"):
            return "bool"
        return "unk"

    def inf_top(self, node):
        return self.inf(node, None)

    def _collect_strlits(self):
        def rn(node):
            if node is None:
                return
            k = node[0]
            if k == "text":
                if node[1] not in self.strlits:
                    self.strlits[node[1]] = f"SL_{len(self.strlits)}"
            elif k == "field":
                rn(node[1])
            elif k == "index":
                rn(node[1])
                rn(node[2])
            elif k == "list":
                for e in node[1]:
                    rn(e)
            elif k == "map":
                for kk, vv in node[1]:
                    rn(vv)
            elif k == "call":
                for a in node[2]:
                    rn(a)
            elif k == "bin":
                rn(node[2])
                rn(node[3])
            elif k == "un":
                rn(node[2])
            elif k == "cmp":
                rn(node[2])
                rn(node[3])
            elif k in ("is", "isnot", "has", "hasnot"):
                rn(node[1])
                rn(node[2])
        for st in self.ast:
            for node in self._walk_nodes(st):
                rn(node)
        for fn in self.fns.values():
            for st in fn.body:
                for node in self._walk_nodes(st):
                    rn(node)
        for h in getattr(self, "handlers_by", {}).values():
            for st in h.body:
                for node in self._walk_nodes(st):
                    rn(node)

    # ================= emit =================
    def fresh(self):
        self.tmp += 1
        return f"_t{self.tmp}"

    def mangle_fn(self, name):
        return "dv_" + name

    def var_sym(self, name, fn):
        if fn:
            if name in fn.params:
                return "P_" + name
            if name in fn.locals:
                return "L_" + name
        if name in self.globals:
            return "G_" + name
        if name == "mouse" and self.kit == "game":
            return None  # special
        return None

    def var_type(self, name, fn):
        if fn:
            if name in fn.params:
                return fn.ptypes[name]
            if name in fn.locals:
                return fn.local_types.get(name, "unk")
        if name in self.globals:
            return self.gtypes.get(name, "unk")
        if name == "mouse" and self.kit == "game":
            return "map"
        return "unk"

    def own_of(self, code, t):
        """wrap an owned typed value so it becomes an owned DEPValue"""
        if t == "num":
            return f"dep_n({code})"
        if t == "bool":
            return f"dep_b({code})"
        if t == "text":
            return f"dep_vs({code})"
        if t == "list":
            return f"dep_vl({code})"
        if t == "map":
            return f"dep_vm({code})"
        return code

    def emit_expr(self, node, fn):
        """-> (c_code, type). c_code is an owned value of that type."""
        k = node[0]
        if k == "num":
            return c_num(node[1]), "num"
        if k == "text":
            slot = self.strlits[node[1]]
            return f"dep_lit(&{slot}, {c_str(node[1])})", "text"
        if k == "bool":
            return ("1" if node[1] else "0"), "bool"
        if k == "nothing":
            return "dep_nothing()", "unk"
        if k == "list":
            tmp = self.fresh()
            parts = [f"({{ DEPList *{tmp} = dep_list_new();"]
            for e in node[1]:
                c, t = self.emit_expr(e, fn)
                parts.append(f"dep_list_push({tmp}, {self.own_of(c, t)});")
            parts.append(f"{tmp}; }})")
            return " ".join(parts), "list"
        if k == "map":
            tmp = self.fresh()
            parts = [f"({{ DEPMap *{tmp} = dep_map_new();"]
            for kk, vv in node[1]:
                if kk[0] == "text":
                    kcode = f"dep_s({c_str(kk[1])})"
                else:
                    kcode = f"dep_n({c_num(kk[1])})"
                c, t = self.emit_expr(vv, fn)
                parts.append(f"dep_map_set({tmp}, {kcode}, {self.own_of(c, t)});")
            parts.append(f"{tmp}; }})")
            return " ".join(parts), "map"
        if k == "name":
            n = node[1]
            if n == "mouse" and self.kit == "game":
                return "dep_own_m(dep_g_mouse())", "map"
            sym = self.var_sym(n, fn)
            if sym is not None:
                t = self.var_type(n, fn)
                if t == "num" or t == "bool":
                    return sym, t
                if t == "text":
                    return f"dep_own_s({sym})", t
                if t == "list":
                    return f"dep_own_l({sym})", t
                if t == "map":
                    return f"dep_own_m({sym})", t
                return f"dep_own({sym})", t
            if n in self.fns and not self.fns[n].params:
                if self.fns[n].ret == "void":
                    raise DepError(f"'{n}' doesn't give a value back (it has "
                                   f"no 'return' with a value, so it can only "
                                   f"be called as a command on its own line)", 0)
                return f"{self.mangle_fn(n)}()", self.fns[n].ret
            if (n, 0) in BUILTINS:
                return f"{BUILTINS[(n, 0)][2]}()", BUILTINS[(n, 0)][1]
            raise DepError(f"'{n}' has no value here (set it first, or check "
                           f"the spelling)", 0)
        if k == "field":
            bc, bt = self.emit_expr(node[1], fn)
            base = self.own_of(bc, bt)
            return f'dep_field2({base}, {c_str(node[2])})', "unk"
        if k == "index":
            cc, ct = self.emit_expr(node[1], fn)
            ic, it = self.emit_expr(node[2], fn)
            return (f"dep_index2({self.own_of(cc, ct)}, {self.own_of(ic, it)})",
                    "unk")
        if k == "call":
            return self.emit_call(node[1], node[2], node[3], fn)
        if k == "bin":
            op = node[1]
            ac, at = self.emit_expr(node[2], fn)
            bc, bt = self.emit_expr(node[3], fn)
            if op in ("+", "-", "*", "/", "%"):
                if at == "num" and bt == "num":
                    if op == "+":
                        return f"({ac} + {bc})", "num"
                    if op == "-":
                        return f"({ac} - {bc})", "num"
                    if op == "*":
                        return f"({ac} * {bc})", "num"
                    if op in ("/", "%"):
                        # evaluate each side once, then guard the divisor:
                        # plain C would print 'inf' (or trap on ints) where
                        # DeadEnd promises an English error
                        l, r = self.fresh(), self.fresh()
                        core = f"{l} / {r}" if op == "/" else f"fmod({l}, {r})"
                        return (f"({{ double {l} = {ac}, {r} = {bc}; "
                                f'if ({r} == 0.0) dep_die("division by zero"); '
                                f"{core}; }})", "num")
                fname = {"+": "dep_add2", "-": "dep_sub2", "*": "dep_mul2",
                         "/": "dep_div2", "%": "dep_mod2"}[op]
                return f"{fname}({self.own_of(ac, at)}, {self.own_of(bc, bt)})", "unk"
            if op == "and":
                if at == "bool" and bt == "bool":
                    return f"({ac} && {bc})", "bool"
                if at == "num" and bt == "num":
                    return f"(({ac}) != 0 && ({bc}) != 0)", "bool"
                return (f"({{ int _r = dep_truthy2({self.own_of(ac, at)}); "
                        f"_r = _r ? dep_truthy2({self.own_of(bc, bt)}) : 0; _r; }})",
                        "bool")
            if op == "or":
                if at == "bool" and bt == "bool":
                    return f"({ac} || {bc})", "bool"
                if at == "num" and bt == "num":
                    return f"(({ac}) != 0 || ({bc}) != 0)", "bool"
                return (f"({{ int _r = dep_truthy2({self.own_of(ac, at)}); "
                        f"_r = _r ? 1 : dep_truthy2({self.own_of(bc, bt)}); _r; }})",
                        "bool")
        if k == "un":
            c, t = self.emit_expr(node[2], fn)
            if node[1] == "neg":
                if t == "num":
                    return f"(-({c}))", "num"
                return f"dep_neg2({self.own_of(c, t)})", "unk"
            if t == "bool":
                return f"(!({c}))", "bool"
            if t == "num":
                return f"(({c}) == 0)", "bool"
            return f"(!dep_truthy2({self.own_of(c, t)}))", "bool"
        if k == "is":
            ac, at = self.emit_expr(node[1], fn)
            bc, bt = self.emit_expr(node[2], fn)
            if at == "num" and bt == "num":
                return f"({ac} == {bc})", "bool"
            if at == "bool" and bt == "bool":
                return f"({ac} == {bc})", "bool"
            return (f"dep_eq2({self.own_of(ac, at)}, {self.own_of(bc, bt)})",
                    "bool")
        if k == "isnot":
            ac, at = self.emit_expr(node[1], fn)
            bc, bt = self.emit_expr(node[2], fn)
            if at == "num" and bt == "num":
                return f"({ac} != {bc})", "bool"
            return (f"dep_neq2({self.own_of(ac, at)}, {self.own_of(bc, bt)})",
                    "bool")
        if k == "cmp":
            op = node[1]
            ac, at = self.emit_expr(node[2], fn)
            bc, bt = self.emit_expr(node[3], fn)
            if at == "num" and bt == "num":
                sym = {">": ">", "<": "<", ">=": ">=", "<=": "<="}[op]
                return f"({ac} {sym} {bc})", "bool"
            a, b = self.own_of(ac, at), self.own_of(bc, bt)
            if op == "<":
                return f"dep_less2({a}, {b})", "bool"
            if op == ">":
                return f"dep_less2({b}, {a})", "bool"
            if op == "<=":
                return f"(!dep_less2({b}, {a}))", "bool"
            return f"(!dep_less2({a}, {b}))", "bool"
        if k == "hits":
            if self.kit != "game":
                raise DepError("'hits' needs 'use game kit' at the top of "
                               f"your program", 0)
            ac, at = self.emit_expr(node[1], fn)
            bc, bt = self.emit_expr(node[2], fn)
            return f"dep_g_hits({self.own_of(ac, at)}, {self.own_of(bc, bt)})", "bool"
        if k == "has":
            ac, at = self.emit_expr(node[1], fn)
            bc, bt = self.emit_expr(node[2], fn)
            return f"dep_has2({self.own_of(ac, at)}, {self.own_of(bc, bt)})", "bool"
        if k == "hasnot":
            ac, at = self.emit_expr(node[1], fn)
            bc, bt = self.emit_expr(node[2], fn)
            return f"dep_hasnot2({self.own_of(ac, at)}, {self.own_of(bc, bt)})", "bool"
        raise DepError(f"internal: cannot emit {k}", 0)

    def emit_call(self, name, args, line, fn, value_ctx=True):
        if name in self.fns:
            f = self.fns[name]
            if len(args) != len(f.params):
                raise DepError(f"{name} takes {len(f.params)} value(s) "
                               f"({', '.join(f.params) or 'none'}) but got "
                               f"{len(args)}", line)
            if f.ret == "void" and value_ctx:
                raise DepError(f"'{name}' doesn't give a value back (it has "
                               f"no 'return' with a value, so it can only be "
                               f"called as a command on its own line)", line)
            cargs = []
            for a, p in zip(args, f.params):
                pt = f.ptypes[p]
                ac, at = self.emit_expr(a, fn)
                cargs.append(self.coerce_arg(ac, at, pt))
            return f"{self.mangle_fn(name)}({', '.join(cargs)})", f.ret
        if name == "moving" and len(args) == 1:
            return self.emit_moving(args[0], line), "bool"
        key = (name, len(args))
        spec = BUILTINS.get(key)
        if spec is None:
            if name in BUILTIN_NAMES:
                raise DepError(f"{name} takes "
                               f"{' or '.join(str(n) for n in sorted(BUILTIN_NAMES[name]))} "
                               f"value(s) but got {len(args)}", line)
            raise DepError(f"I don't know a function called '{name}'", line)
        argspec, ret, cfunc = spec
        if ret == "void" and value_ctx:
            raise DepError(f"'{name}' doesn't give a value back, so it can "
                           f"only be used as a command on its own line", line)
        cargs = []
        for a, s in zip(args, argspec):
            ac, at = self.emit_expr(a, fn)
            if s == "n":
                if at == "num":
                    cargs.append(ac)
                else:
                    cargs.append(f"dep_as_num({self.own_of(ac, at)})")
            else:
                cargs.append(self.own_of(ac, at))
        return f"{cfunc}({', '.join(cargs)})", ret

    def emit_moving(self, node, line):
        """`if moving dot.x` / `if moving dot` -> slot activity query."""
        parts = []
        n = node
        while n[0] == "field":
            parts.append(n[2])
            n = n[1]
        if n[0] != "name":
            raise DepError("'moving' needs a target like dot.x", line)
        parts.append(n[1])
        parts.reverse()
        key = ".".join(parts)
        if key in self.motion_slots:
            return f"dep_m_active({self.motion_slots[key]})"
        if len(parts) == 1 and key in self.motion_ranges:
            lo, hi = self.motion_ranges[key]
            return f"dep_m_any_active_range({lo}, {hi})"
        raise DepError(f"no animation targets {key} yet -- write "
                       f"'move {key} toward ...' first", line)

    def emit_image_fx(self, args, cl, line, fn):
        """an image call with frame/part/flipped/mirrored clauses"""
        if len(args) not in (3, 5):
            raise DepError("image takes (file, x, y) or (file, x, y, w, h) "
                           "values", line)
        def num_code(node):
            c, t = self.emit_expr(node, fn)
            if t == "num":
                return c
            return f"dep_as_num({self.own_of(c, t)})"
        def txt_code(node):
            c, t = self.emit_expr(node, fn)
            return self.own_of(c, t)      # -> an owned DEPValue (dep_vs etc.)
        file_c = txt_code(args[0])
        coords = [num_code(a) for a in args[1:]]
        while len(coords) < 4:
            coords.append("-1.0")          # w/h < 0 = the picture's own size
        fv = "1" if cl.get("flipv") else "0"
        fh = "1" if cl.get("fliph") else "0"
        if "frame" in cl:
            idx, cnt = cl["frame"]
            return (f"dep_g_image_frame({file_c}, {coords[0]}, {coords[1]}, "
                    f"{coords[2]}, {coords[3]}, {num_code(idx)}, "
                    f"{num_code(cnt)}, {fv}, {fh})"), "void"
        px, py, pw, ph = cl["part"]
        return (f"dep_g_image_part({file_c}, {coords[0]}, {coords[1]}, "
                f"{coords[2]}, {coords[3]}, {num_code(px)}, {num_code(py)}, "
                f"{num_code(pw)}, {num_code(ph)}, {fv}, {fh})"), "void"

    def coerce_arg(self, code, at, pt):
        """coerce an owned typed value into a parameter of type pt"""
        if pt == at:
            return code
        if pt == "num":
            return f"dep_as_num({self.own_of(code, at)})"
        if pt == "bool":
            return f"dep_as_bool({self.own_of(code, at)})"
        if pt == "text":
            if at == "text":
                return code
            return f"dep_as_str({self.own_of(code, at)})"
        if pt == "list":
            if at == "list":
                return code
            return f"dep_as_list({self.own_of(code, at)})"
        if pt == "map":
            if at == "map":
                return code
            return f"dep_as_map({self.own_of(code, at)})"
        return self.own_of(code, at)

    def cond_code(self, node, fn):
        c, t = self.emit_expr(node, fn)
        if t == "bool":
            return c
        if t == "num":
            return f"(({c}) != 0)"
        if t == "text":
            return f"dep_truthy_s2({c})"
        return f"dep_truthy2({c})"

    # ---------------- statements ----------------
    def emit_stmts(self, stmts, fn, out, indent):
        pad = "    " * indent
        for st in stmts:
            self.emit_stmt(st, fn, out, indent)

    def emit_stmt(self, st, fn, out, indent):
        pad = "    " * indent
        k = st[0]
        # keep the runtime's line counter in step so runtime errors point at
        # the right source line (dep_die prints __dep_line)
        ln = st[3] if k == "callstmt" else \
            (st[-1] if isinstance(st[-1], int) else None)
        if ln:
            out.append(f"{pad}__dep_line = {ln};")
        if k == "set":
            self.emit_store(st[1], st[2], fn, out, pad)
            return
        if k == "change":
            read = self._target_read(st[1])
            self.emit_store(st[1], ("bin", "+", read, st[2]), fn, out, pad)
            return
        if k == "print":
            args = st[1]
            if len(args) == 1:
                c, t = self.emit_expr(args[0], fn)
                if t == "num":
                    out.append(f"{pad}dep_print_num({c});")
                else:
                    out.append(f"{pad}dep_print2({self.own_of(c, t)});")
            else:
                vals = []
                for a in args:
                    c, t = self.emit_expr(a, fn)
                    vals.append(self.own_of(c, t))
                arr = self.fresh()
                rel = "".join(f" dep_release({arr}[{i}]);" for i in range(len(vals)))
                out.append(f"{pad}{{ DEPValue {arr}[] = {{{', '.join(vals)}}}; "
                           f"dep_print_many({arr}, {len(vals)});{rel} }}")
            return
        if k == "if":
            branches, els = st[1], st[2]
            for i, (cond, body) in enumerate(branches):
                lead = "if" if i == 0 else "else if"
                out.append(f"{pad}{lead} ({self.cond_code(cond, fn)}) {{")
                self.emit_stmts(body, fn, out, indent + 1)
                out.append(f"{pad}}}")
            if els:
                out.append(f"{pad}else {{")
                self.emit_stmts(els, fn, out, indent + 1)
                out.append(f"{pad}}}")
            return
        if k == "while":
            out.append(f"{pad}while ({self.cond_code(st[1], fn)}) {{")
            self.emit_stmts(st[2], fn, out, indent + 1)
            out.append(f"{pad}}}")
            return
        if k == "repeat_n":
            c, t = self.emit_expr(st[1], fn)
            n = c if t == "num" else f"dep_as_num({self.own_of(c, t)})"
            r = self.fresh()
            out.append(f"{pad}{{ double {r} = {n};")
            out.append(f"{pad}  for (long _i = 0; _i < (long){r}; _i++) {{")
            self.emit_stmts(st[2], fn, out, indent + 2)
            out.append(f"{pad}  }}")
            out.append(f"{pad}}}")
            return
        if k == "repeat_forever":
            out.append(f"{pad}for (;;) {{")
            self.emit_stmts(st[1], fn, out, indent + 1)
            out.append(f"{pad}}}")
            return
        if k == "repeat_for":
            var, a, b, step, body = st[1], st[2], st[3], st[4], st[5]
            ac, at = self.emit_expr(a, fn)
            bc, bt = self.emit_expr(b, fn)
            av = ac if at == "num" else f"dep_as_num({self.own_of(ac, at)})"
            bv = bc if bt == "num" else f"dep_as_num({self.own_of(bc, bt)})"
            if step is not None:
                sc, stt = self.emit_expr(step, fn)
                sv = sc if stt == "num" else f"dep_as_num({self.own_of(sc, stt)})"
            else:
                sv = "1"
            vt = self.var_type(var, fn)
            sym = self.var_sym(var, fn) or ("L_" + var)
            ta, tb, ts = self.fresh(), self.fresh(), self.fresh()
            out.append(f"{pad}{{ double {ta} = {av}, {tb} = {bv}, {ts} = {sv};")
            out.append(f"{pad}  if ({ts} == 0) dep_die(\"repeat step cannot be zero\");")
            iv = self.fresh()
            out.append(f"{pad}  for (double {iv} = {ta}; ({ts} > 0 ? {iv} <= {tb} : {iv} >= {tb}); {iv} += {ts}) {{")
            if vt == "num":
                out.append(f"{pad}    {sym} = {iv};")
            elif vt == "unk":
                out.append(f"{pad}    dep_release({sym}); {sym} = dep_n({iv});")
            elif vt == "text":
                out.append(f"{pad}    dep_release_s({sym}); {sym} = dep_as_str(dep_n({iv}));")
            else:
                out.append(f"{pad}    {sym} = dep_as_num(dep_n({iv}));")
            self.emit_stmts(body, fn, out, indent + 2)
            out.append(f"{pad}  }}")
            out.append(f"{pad}}}")
            return
        if k == "foreach":
            var, coll, body = st[1], st[2], st[3]
            cc, ct = self.emit_expr(coll, fn)
            cl = self.fresh()
            vt = self.var_type(var, fn)
            sym = self.var_sym(var, fn) or ("L_" + var)
            out.append(f"{pad}{{ DEPList *{cl} = dep_as_list({self.own_of(cc, ct)});")
            idx = self.fresh()
            out.append(f"{pad}  for (long {idx} = 0; {idx} < {cl}->len; {idx}++) {{")
            if vt == "num":
                out.append(f"{pad}    {sym} = dep_as_num(dep_own({cl}->items[{idx}]));")
            elif vt == "bool":
                out.append(f"{pad}    {sym} = dep_as_bool(dep_own({cl}->items[{idx}]));")
            elif vt == "unk":
                out.append(f"{pad}    dep_release({sym}); {sym} = dep_own({cl}->items[{idx}]);")
            elif vt == "text":
                out.append(f"{pad}    dep_release_s({sym}); {sym} = dep_as_str(dep_own({cl}->items[{idx}]));")
            elif vt == "list":
                out.append(f"{pad}    dep_release_l({sym}); {sym} = dep_as_list(dep_own({cl}->items[{idx}]));")
            else:
                out.append(f"{pad}    dep_release_m({sym}); {sym} = dep_as_map(dep_own({cl}->items[{idx}]));")
            self.emit_stmts(body, fn, out, indent + 2)
            out.append(f"{pad}  }}")
            out.append(f"{pad}  dep_release_l({cl});")
            out.append(f"{pad}}}")
            return
        if k == "return":
            if fn is None:
                raise DepError("'return' can only be used inside a function", 0)
            if st[1] is None:
                rv = {"num": "0", "bool": "0", "text": "dep_s(\"\")",
                      "list": "dep_list_new()", "map": "dep_map_new()",
                      "unk": "dep_nothing()"}.get(fn.ret, "dep_nothing()")
                if fn.ret == "void":
                    out.append(f"{pad}{fn.epilogue}; return;")
                else:
                    out.append(f"{pad}{{ {fn.epilogue}; return {rv}; }}")
                return
            c, t = self.emit_expr(st[1], fn)
            if fn.ret == "void":
                raise DepError("this function has no 'return' with a value, "
                               "so it cannot give one back here", 0)
            line = self.store_line(t, c, fn.ret)
            rv = self.fresh()
            out.append(f"{pad}{{ {CTYPE[fn.ret]} {rv} = {line}; {fn.epilogue}; return {rv}; }}")
            return
        if k == "break":
            out.append(f"{pad}break;")
            return
        if k == "continue":
            out.append(f"{pad}continue;")
            return
        if k == "exit":
            out.append(f"{pad}dep_shutdown(); exit(0);")
            return
        if k == "use":
            return
        if k == "everytime":
            if not getattr(self, "_in_frame", False):
                raise DepError("'every N seconds' only works inside "
                               "'every frame' -- it needs the game clock",
                               st[-1] if isinstance(st[-1], int) else 0)
            cnt = self._num_expr(st[1], fn)
            secs = f"({cnt} / 1000.0)" if st[2] else f"({cnt})"
            acc = self.fresh()
            out.append(f"{pad}{{ static double {acc} = 0.0;   /* every-timer */")
            out.append(f"{pad}  {acc} += dep_g_delta();")
            out.append(f"{pad}  if ({acc} >= {secs}) {{")
            out.append(f"{pad}    {acc} = 0.0;")
            self.emit_stmts(st[3], fn, out, indent + 2)
            out.append(f"{pad}  }}")
            out.append(f"{pad}}}")
            return
        if k == "canvas_paint":
            nc, nt = self.emit_expr(st[1], fn)
            name_c = f"dep_vs({nc})" if nt == "text" else \
                f"dep_own_s(dep_as_str({self.own_of(nc, nt)}))"
            out.append(f"{pad}dep_g_canvas_open({name_c});")
            self.emit_stmts(st[2], fn, out, indent + 1)
            out.append(f"{pad}dep_g_canvas_close();")
            return
        if k == "canvas_show":
            nc, nt = self.emit_expr(st[1], fn)
            name_c = f"dep_vs({nc})" if nt == "text" else \
                f"dep_own_s(dep_as_str({self.own_of(nc, nt)}))"
            x = y = w = h = None
            if st[2] is not None:
                x = self._num_expr(st[2], fn)
                y = self._num_expr(st[3], fn)
                if st[4] is not None:
                    w = self._num_expr(st[4], fn)
                    h = self._num_expr(st[5], fn)
            out.append(f"{pad}dep_g_canvas_show({name_c}, "
                       f"{1 if x is not None else 0}, {x if x is not None else '0.0'}, "
                       f"{y if y is not None else '0.0'}, "
                       f"{1 if w is not None else 0}, {w if w is not None else '0.0'}, "
                       f"{h if h is not None else '0.0'});")
            return
        if k == "canvas_clear":
            nc, nt = self.emit_expr(st[1], fn)
            name_c = f"dep_vs({nc})" if nt == "text" else \
                f"dep_own_s(dep_as_str({self.own_of(nc, nt)}))"
            cc, ct = self.emit_expr(st[2], fn)
            out.append(f"{pad}dep_g_canvas_clear({name_c}, {self.own_of(cc, ct)});")
            return
        if k == "canvas_save":
            nc, nt = self.emit_expr(st[1], fn)
            name_c = f"dep_vs({nc})" if nt == "text" else \
                f"dep_own_s(dep_as_str({self.own_of(nc, nt)}))"
            fc, ft = self.emit_expr(st[2], fn)
            file_c = f"dep_vs({fc})" if ft == "text" else \
                f"dep_own_s(dep_as_str({self.own_of(fc, ft)}))"
            out.append(f"{pad}dep_g_canvas_save({name_c}, {file_c});")
            return
        if k == "cam_pan":
            mode, x, y, dur, dur_ms, feel = st[1], st[2], st[3], st[4], st[5], st[6]
            xc = self._num_expr(x, fn)
            yc = self._num_expr(y, fn)
            d = "0.4"
            if dur is not None:
                v = self._num_expr(dur, fn)
                d = f"({v} / 1000.0)" if dur_ms else f"({v})"
            fl = c_str(feel) if feel else '""'
            fname = "dep_m_pan_to" if mode == "to" else "dep_m_pan_by"
            out.append(f"{pad}{fname}({xc}, {yc}, {d}, {fl});")
            return
        if k == "cam_follow":
            xc = self._num_expr(st[1], fn)
            yc = self._num_expr(st[2], fn)
            sp = self._num_expr(st[3], fn) if st[3] is not None else "0"
            out.append(f"{pad}dep_m_follow({xc}, {yc}, {sp});")
            return
        if k == "cam_release":
            out.append(f"{pad}dep_m_follow_off();")
            return
        if k == "make":
            kind, title, opts, line = st[1], st[2], st[3], st[4]
            tc, tt = self.emit_expr(title, fn)

            def opt(name, default):
                if name in opts:
                    c, t = self.emit_expr(opts[name], fn)
                    if t == "num":
                        return c
                    return f"dep_as_num({self.own_of(c, t)})"
                return default
            if kind == "game":
                fs = opts.get("fullscreen")
                if fs is not None:
                    c, t = self.emit_expr(fs, fn)
                    fsc = c if t == "bool" else f"dep_truthy2({self.own_of(c, t)})"
                else:
                    fsc = "0"
                out.append(f"{pad}dep_game_setup({self.own_of(tc, tt)}, "
                           f"{opt('width', '800')}, {opt('height', '600')}, "
                           f"{opt('fps', '60')}, {fsc});")
            else:
                out.append(f"{pad}dep_app_setup({self.own_of(tc, tt)}, "
                           f"{opt('width', '480')}, {opt('height', '320')});")
            return
        if k == "when":
            kind, arg, body, line = st[1], st[2], st[3], st[4]
            # registration emitted at this point in main
            if kind == "game_starts":
                self.saw_start = True
                out.append(f"{pad}dep_game_config.on_start = H_game_starts;")
            else:
                self.saw_click = True
                out.append(f"{pad}dep_app_on_click({c_str(arg)}, H_btn_{self.btn_ids[(arg)]});")
            return
        if k == "every":
            self.saw_frame = True
            out.append(f"{pad}dep_game_config.on_frame = H_frame;")
            return
        if k == "run":
            if st[1] == "game":
                self.ran["game"] = True
                out.append(f"{pad}dep_game_run();")
            else:
                self.ran["app"] = True
                out.append(f"{pad}dep_app_run();")
            return
        if k == "addwidget":
            if self.kit != "app":
                raise DepError("adding widgets needs 'use app kit' at the top "
                               f"of your program", line)
            self.saw_widget = True
            widget, name_node, x, y, w, h, line = st[1], st[2], st[3], st[4], st[5], st[6], st[7]
            def numc(e):
                c, t = self.emit_expr(e, fn)
                return c if t == "num" else f"dep_as_num({self.own_of(c, t)})"
            wc = numc(w) if w is not None else "-1"
            hc = numc(h) if h is not None else "-1"
            if name_node[0] == "text":
                out.append(f"{pad}dep_app_add({WIDGETS[widget]}, {c_str(name_node[1])}, "
                           f"{numc(x)}, {numc(y)}, {wc}, {hc});")
            else:
                nc, nt_ = self.emit_expr(name_node, fn)
                if nt_ != "text":
                    nc = f"dep_as_str({self.own_of(nc, nt_)})"
                tmp = self.fresh()
                out.append(f"{pad}{{ DEPStr *{tmp} = {nc}; "
                           f"dep_app_add({WIDGETS[widget]}, {tmp}->chars, "
                           f"{numc(x)}, {numc(y)}, {wc}, {hc}); dep_release_s({tmp}); }}")
            return
        if k == "append":
            target, expr, line = st[1], st[2], st[3]
            if target[0] == "tname" and target[1] == "mouse":
                raise DepError("'mouse' belongs to the game kit and cannot "
                               "be changed", line)
            if target[0] not in ("tname", "tfield", "tindex"):
                raise DepError("add ... to ... needs a list name after 'to'", line)
            bc, btt = self._container_of(target, fn)
            c, t = self.emit_expr(expr, fn)
            out.append(f"{pad}dep_push2({self.own_of(bc, btt)}, {self.own_of(c, t)});")
            return
        if k == "remove":
            target, expr, by_index, line = st[1], st[2], st[3], st[4]
            if target[0] == "tname" and target[1] == "mouse":
                raise DepError("'mouse' belongs to the game kit and cannot "
                               "be changed", line)
            if target[0] not in ("tname", "tfield", "tindex"):
                raise DepError("remove ... from ... needs a list or map "
                               "name after 'from'", line)
            bc, btt = self._container_of(target, fn)
            c, t = self.emit_expr(expr, fn)
            base = self.own_of(bc, btt)
            val = self.own_of(c, t)
            if by_index:
                out.append(f"{pad}dep_remove_at2({base}, {val});")
            else:
                out.append(f"{pad}dep_remove_from2({base}, {val});")
            return
        if k == "setwidget":
            if self.kit != "app":
                raise DepError("changing widgets needs 'use app kit' at the "
                               f"top of your program", line)
            widget, name, expr, line = st[1], st[2], st[3], st[4]
            c, t = self.emit_expr(expr, fn)
            if widget in ("label", "field"):
                out.append(f"{pad}dep_app_set_text({c_str(name)}, {self.own_of(c, t)});")
            else:
                out.append(f"{pad}dep_app_set_val({c_str(name)}, {self.own_of(c, t)});")
            return
        if k == "callstmt":
            name, args, line = st[1], st[2], st[3]
            clauses = st[4] if len(st) > 4 else None
            if name == "image" and clauses:
                c, t = self.emit_image_fx(args, clauses, line, fn)
            else:
                c, t = self.emit_call(name, args, line, fn, value_ctx=False)
            if t == "num" or t == "bool":
                out.append(f"{pad}(void)({c});")
            elif t == "void":
                out.append(f"{pad}{c};")
            elif t == "text":
                r = self.fresh()
                out.append(f"{pad}{{ DEPStr *{r} = {c}; dep_release_s({r}); }}")
            elif t == "list":
                r = self.fresh()
                out.append(f"{pad}{{ DEPList *{r} = {c}; dep_release_l({r}); }}")
            elif t == "map":
                r = self.fresh()
                out.append(f"{pad}{{ DEPMap *{r} = {c}; dep_release_m({r}); }}")
            else:
                r = self.fresh()
                out.append(f"{pad}{{ DEPValue {r} = {c}; dep_release({r}); }}")
            return
        if k in ("mmove", "mspring"):
            return self.emit_motion_stmt(st, fn, out, pad)
        if k == "mtl_make":
            out.append(f"{pad}dep_m_tl_new({c_str(st[1])});")
            return
        if k == "mtl_add":
            return self.emit_tl_add(st, fn, out, pad)
        if k == "mtl_play":
            name, repeat, forever, line = st[1], st[2], st[3], st[4]
            if forever:
                rep = "-1.0"
            elif repeat is not None:
                rep = self._num_expr(repeat, fn)
            else:
                rep = "1.0"
            out.append(f"{pad}dep_m_tl_play({c_str(name)}, {rep});")
            return
        if k == "mtl_pause":
            out.append(f"{pad}dep_m_tl_pause({c_str(st[1])});")
            return
        if k == "mtl_resume":
            out.append(f"{pad}dep_m_tl_resume({c_str(st[1])});")
            return
        if k == "mtl_stop":
            out.append(f"{pad}dep_m_tl_stop({c_str(st[1])});")
            return
        if k == "mstop":
            if st[1] is None:
                out.append(f"{pad}dep_m_stop_all();")
                return
            parts = self._target_parts(st[1])
            if parts is None:
                raise DepError("stop moving needs a target like score or "
                               "dot.x -- indexed targets like m[1] are not "
                               "animated", st[-1])
            key = self._slot_key(st[1])
            if key in self.motion_slots:
                out.append(f"{pad}dep_m_stop({self.motion_slots[key]});")
                return
            base, chain, last = parts
            if last is None and base in self.motion_ranges:
                lo, hi = self.motion_ranges[base]
                out.append(f"{pad}dep_m_stop_range({lo}, {hi});")
                return
            raise DepError(f"no animation targets {key} -- nothing to stop",
                           st[-1])
        if k == "madvance":
            v = self._num_expr(st[1], fn)
            secs = f"({v} / 1000.0)" if st[2] else f"({v})"
            out.append(f"{pad}dep_motion_advance({secs});")
            return
        if k == "mui":
            return self.emit_ui_stmt(st, fn, out, pad)
        if k == "mwait":
            raise DepError("'wait' only makes sense inside a timeline "
                           "(add wait 1 second to timeline \"name\")", st[-1])
        if k == "mfx":
            return self.emit_fx_stmt(st, fn, out, pad)
        if k == "mpart":
            return self.emit_part_stmt(st, fn, out, pad)
        raise DepError(f"internal: unknown statement {k}", 0)

    # ---------------- motion kit emitters ----------------

    def _slot_id(self, tgt, line):
        key = self._slot_key(tgt)
        if key not in self.motion_slots:
            raise DepError(f"no animation slot for {key}", line)
        return self.motion_slots[key]

    def _emit_one_motion(self, kind, target, value, opts, fn, out, pad,
                         sid):
        to_v = self._num_expr(value, fn)
        dur = self._motion_duration(opts, "dur", "1.0")
        delay = self._motion_duration(opts, "delay", "0.0")
        if opts["forever"]:
            rep = "-1.0"
        elif opts["repeat"] is not None:
            rep = self._num_expr(opts["repeat"], fn)
        else:
            rep = "1.0"
        feel = c_str(opts["feel"] or "smooth")
        ping = "1" if opts["pingpong"] else "0"
        if kind == "mmove":
            from_v, has_from = "0.0", "0"
            if opts["from_expr"] is not None:
                from_v = self._num_expr(opts["from_expr"], fn)
                has_from = "1"
            out.append(f"{pad}dep_m_move({sid}, {feel}, {to_v}, {dur}, "
                       f"{delay}, {rep}, {ping}, {from_v}, {has_from});")
            return
        stiff, damp = self._spring_codes(opts, fn)
        tmp = self.fresh()
        out.append(f"{pad}{{ double {tmp}s = {stiff};")
        out.append(f"{pad}  double {tmp}d = {damp};")
        out.append(f"{pad}  dep_m_spring({sid}, {to_v}, {tmp}s, {tmp}d);")
        out.append(f"{pad}}}")

    def emit_motion_stmt(self, st, fn, out, pad):
        kind, target, value, opts, line = st[0], st[1], st[2], st[3], st[4]
        fields = self._motion_fields(target, value, line)
        if fields is not None:
            # one engine slot per map field: move dot toward {x: 1, y: 2}
            for fname, fval in fields:
                sid = self._slot_id(("tfield", target, fname), line)
                self._emit_one_motion(kind, target, fval, opts, fn, out,
                                      pad, sid)
            return
        sid = self._slot_id(target, line)
        self._emit_one_motion(kind, target, value, opts, fn, out, pad, sid)

    def emit_tl_add(self, st, fn, out, pad):
        tlname, inner, line = st[1], st[2], st[3]
        tln = c_str(tlname)
        tg = "1" if (isinstance(inner[3], dict) and inner[3].get("together")) else "0"
        if inner[0] in ("mmove", "mspring"):
            opts = inner[3]
            dur = self._motion_duration(opts, "dur", "1.0")
            delay = self._motion_duration(opts, "delay", "0.0")
            if opts["forever"]:
                rep = "-1.0"
            elif opts["repeat"] is not None:
                rep = self._num_expr(opts["repeat"], fn)
            else:
                rep = "1.0"
            ping = "1" if opts["pingpong"] else "0"
            feel = c_str(opts["feel"] or "smooth")
            # `starting from N` must survive the trip into the timeline:
            # the step overrides the slot's starting value when it fires
            if opts["from_expr"] is not None:
                from_v, has_from = self._num_expr(opts["from_expr"], fn), "1"
            else:
                from_v, has_from = "-1.0", "0"
            fields = self._motion_fields(inner[1], inner[2], line)
            if fields is not None:
                # each map field becomes its own step; fields after the
                # first run together with it (one sentence = one moment)
                for fname, fval in fields:
                    sid = self._slot_id(("tfield", inner[1], fname), line)
                    to_v = self._num_expr(fval, fn)
                    ftg = tg if fname == fields[0][0] else "1"
                    if inner[0] == "mmove":
                        out.append(f"{pad}dep_m_tl_add({tln}, {sid}, {feel}, "
                                   f"{to_v}, {dur}, {delay}, {rep}, {ping}, "
                                   f"-1.0, -1.0, 0, {ftg}, "
                                   f"{from_v}, {has_from});")
                    else:
                        stiff, damp = self._spring_codes(opts, fn)
                        tmp = self.fresh()
                        out.append(f"{pad}{{ double {tmp}s = {stiff};")
                        out.append(f"{pad}  double {tmp}d = {damp};")
                        out.append(f"{pad}  dep_m_tl_add({tln}, {sid}, "
                                   f"\"smooth\", {to_v}, 1.0, {delay}, {rep}, "
                                   f"{ping}, {tmp}s, {tmp}d, 1, {ftg}, "
                                   f"{from_v}, {has_from});")
                        out.append(f"{pad}}}")
            else:
                sid = self._slot_id(inner[1], line)
                to_v = self._num_expr(inner[2], fn)
                if inner[0] == "mmove":
                    out.append(f"{pad}dep_m_tl_add({tln}, {sid}, {feel}, {to_v}, "
                               f"{dur}, {delay}, {rep}, {ping}, -1.0, -1.0, 0, "
                               f"{tg}, {from_v}, {has_from});")
                else:
                    stiff, damp = self._spring_codes(opts, fn)
                    tmp = self.fresh()
                    out.append(f"{pad}{{ double {tmp}s = {stiff};")
                    out.append(f"{pad}  double {tmp}d = {damp};")
                    out.append(f"{pad}  dep_m_tl_add({tln}, {sid}, \"smooth\", "
                               f"{to_v}, 1.0, {delay}, {rep}, {ping}, "
                               f"{tmp}s, {tmp}d, 1, {tg}, "
                               f"{from_v}, {has_from});")
                    out.append(f"{pad}}}")
            return
        if inner[0] == "mui":
            op, widget, name, opts = inner[1], inner[2], inner[3], inner[4]
            tg = "1" if opts.get("together") else "0"
            opid = {"pop_in": 0, "pop_out": 1, "fade_in": 2, "fade_out": 3,
                    "slide_in": 4, "slide_out": 5, "shake": 6, "bump": 7,
                    "glide": 8}[op]
            dur = self._motion_duration(opts, "dur", "0.0")
            feel = c_str(opts["feel"] or "")
            dirid = {"left": 0, "right": 1, "top": 2, "bottom": 3,
                     "up": 2, "down": 3}.get(opts["dir"], 0)
            xv = self._num_expr(opts["x"], fn) if opts["x"] is not None else "0.0"
            yv = self._num_expr(opts["y"], fn) if opts["y"] is not None else "0.0"
            sv = (self._num_expr(opts["strength"], fn)
                  if opts["strength"] is not None else "0.0")
            out.append(f"{pad}dep_m_tl_add_ui({tln}, {opid}, {c_str(name)}, "
                       f"{dur}, {feel}, {dirid}, {xv}, {yv}, {sv}, {tg});")
            return
        if inner[0] == "mwait":
            v = self._num_expr(inner[1], fn)
            dur = f"({v} / 1000.0)" if inner[2] else f"({v})"
            out.append(f"{pad}dep_m_tl_add_wait({tln}, {dur}, 0);")
            return
        raise DepError("only move, spring, wait and UI animation steps can be "
                       "added to a timeline", line)

    def emit_ui_stmt(self, st, fn, out, pad):
        op, widget, name, opts, line = st[1], st[2], st[3], st[4], st[5]
        nm = c_str(name)
        feel = self._lit_code(opts["feel"]) if opts["feel"] else 'dep_s("")'
        if op in ("pop_in", "pop_out"):
            c = "dep_ui_pop_in" if op == "pop_in" else "dep_ui_pop_out"
            dur = self._motion_duration(opts, "dur", "0.0")
            out.append(f"{pad}{c}({nm}, {dur}, {feel});")
        elif op in ("fade_in", "fade_out"):
            c = "dep_ui_fade_in" if op == "fade_in" else "dep_ui_fade_out"
            dur = self._motion_duration(opts, "dur", "0.0")
            out.append(f"{pad}{c}({nm}, {dur}, {feel});")
        elif op in ("slide_in", "slide_out"):
            c = "dep_ui_slide_in" if op == "slide_in" else "dep_ui_slide_out"
            dur = self._motion_duration(opts, "dur", "0.0")
            out.append(f"{pad}{c}({nm}, {self._lit_code(opts['dir'])}, "
                       f"{dur}, {feel});")
        elif op == "glide":
            dur = self._motion_duration(opts, "dur", "0.0")
            xv = self._num_expr(opts["x"], fn)
            yv = self._num_expr(opts["y"], fn)
            out.append(f"{pad}dep_ui_glide({nm}, {xv}, {yv}, {dur}, {feel});")
        elif op == "shake":
            sv = (self._num_expr(opts["strength"], fn)
                  if opts["strength"] is not None else "0.0")
            out.append(f"{pad}dep_ui_shake({nm}, {sv});")
        elif op == "bump":
            out.append(f"{pad}dep_ui_bump({nm});")
        else:
            raise DepError(f"internal: unknown UI animation '{op}'", line)

    def emit_fx_stmt(self, st, fn, out, pad):
        op, opts = st[1], st[2]
        if op == "shake":
            sv = (self._num_expr(opts["strength"], fn)
                  if opts["strength"] is not None else "8.0")
            dur = self._motion_duration(opts, "dur", "0.3")
            out.append(f"{pad}dep_g_shake({sv}, {dur});")
        elif op == "flash":
            color = self.own_of(*self.emit_expr(opts["color"], fn))
            dur = self._motion_duration(opts, "dur", "0.15")
            out.append(f"{pad}dep_g_flash({color}, {dur});")
        elif op in ("fadeto", "fadefrom"):
            color = self.own_of(*self.emit_expr(opts["color"], fn))
            c = "dep_g_fade_to" if op == "fadeto" else "dep_g_fade_from"
            dur = self._motion_duration(opts, "dur", "1.0")
            out.append(f"{pad}{c}({color}, {dur});")
        elif op == "zoom":
            tv = self._num_expr(opts["target"], fn)
            dur = self._motion_duration(opts, "dur", "0.5")
            feel = self._lit_code(opts["feel"]) if opts["feel"] else 'dep_s("")'
            out.append(f"{pad}dep_g_zoom({tv}, {dur}, {feel});")
        elif op == "reset":
            out.append(f"{pad}dep_m_reset_screen();")
        else:
            raise DepError(f"internal: unknown screen effect '{op}'", 0)

    def emit_part_stmt(self, st, fn, out, pad):
        op, payload = st[1], st[2]
        if op == "clear":
            out.append(f"{pad}dep_m_clear_particles();")
            return
        if op == "burst":
            n, kind, x, y, opts = payload
            color = (self.own_of(*self.emit_expr(opts["color"], fn))
                     if opts["color"] is not None else 'dep_s("")')
            speed = (self._num_expr(opts["speed"], fn)
                     if opts["speed"] is not None else "1.0")
            size = (self._num_expr(opts["size"], fn)
                    if opts["size"] is not None else "1.0")
            life = (self._num_expr(opts["life"], fn)
                    if opts["life"] is not None else "0.0")
            out.append(f"{pad}dep_g_burst({self._lit_code(kind)}, {self._num_expr(n, fn)}, "
                       f"{self._num_expr(x, fn)}, {self._num_expr(y, fn)}, "
                       f"{color}, {speed}, {size}, {life});")
            return
        n, opts = payload
        color = (self.own_of(*self.emit_expr(opts["color"], fn))
                 if opts["color"] is not None else 'dep_s("")')
        speed = (self._num_expr(opts["speed"], fn)
                 if opts["speed"] is not None else "1.0")
        size = (self._num_expr(opts["size"], fn)
                if opts["size"] is not None else "1.0")
        # `life` is a documented option of rain/snow -- it used to be parsed
        # and then silently dropped
        life = (self._num_expr(opts["life"], fn)
                if opts["life"] is not None else "0.0")
        c = "dep_g_rain" if op == "rain" else "dep_g_snow"
        out.append(f"{pad}{c}({self._num_expr(n, fn)}, {color}, {speed}, "
                   f"{size}, {life});")

    def store_line(self, from_t, code, to_t):
        """C assignment RHS converting owned typed value to type to_t"""
        if to_t == from_t:
            return code
        if to_t == "num":
            return f"dep_as_num({self.own_of(code, from_t)})"
        if to_t == "bool":
            return f"dep_as_bool({self.own_of(code, from_t)})"
        if to_t == "text":
            if from_t == "text":
                return code
            return f"dep_as_str({self.own_of(code, from_t)})"
        if to_t == "list":
            if from_t == "list":
                return code
            return f"dep_as_list({self.own_of(code, from_t)})"
        if to_t == "map":
            if from_t == "map":
                return code
            return f"dep_as_map({self.own_of(code, from_t)})"
        return self.own_of(code, from_t)

    def emit_store(self, tgt, rhs, fn, out, pad):
        if tgt[0] == "tname":
            name = tgt[1]
            if name == "mouse":
                raise DepError("'mouse' belongs to the game kit and cannot be "
                               "changed", 0)
            sym = self.var_sym(name, fn)
            if sym is None:
                raise DepError(f"'{name}' has no value here", 0)
            vt = self.var_type(name, fn)
            c, t = self.emit_expr(rhs, fn)
            if vt == "num" or vt == "bool":
                out.append(f"{pad}{sym} = {self.store_line(t, c, vt)};")
            elif vt == "text":
                r = self.fresh()
                out.append(f"{pad}{{ DEPStr *{r} = {self.store_line(t, c, vt)}; "
                           f"dep_release_s({sym}); {sym} = {r}; }}")
            elif vt == "list":
                r = self.fresh()
                out.append(f"{pad}{{ DEPList *{r} = {self.store_line(t, c, vt)}; "
                           f"dep_release_l({sym}); {sym} = {r}; }}")
            elif vt == "map":
                r = self.fresh()
                out.append(f"{pad}{{ DEPMap *{r} = {self.store_line(t, c, vt)}; "
                           f"dep_release_m({sym}); {sym} = {r}; }}")
            else:
                r = self.fresh()
                out.append(f"{pad}{{ DEPValue {r} = {self.store_line(t, c, vt)}; "
                           f"dep_release({sym}); {sym} = {r}; }}")
            return
        if tgt[0] == "tfield":
            base, field = tgt[1], tgt[2]
            if base[0] == "tname":
                bc, btt = self.emit_expr(("name", base[1]), fn)
            else:
                bc, btt = self.emit_expr(self._target_read(base), fn)
            base_code = self.own_of(bc, btt)
            c, t = self.emit_expr(rhs, fn)
            out.append(f"{pad}dep_setfield2({base_code}, {c_str(field)}, "
                       f"{self.own_of(c, t)});")
            return
        if tgt[0] == "tindex":
            base, idx = tgt[1], tgt[2]
            if base[0] == "tname":
                bc, btt = self.emit_expr(("name", base[1]), fn)
            else:
                bc, btt = self.emit_expr(self._target_read(base), fn)
            base_code = self.own_of(bc, btt)
            ic, it = self.emit_expr(idx, fn)
            c, t = self.emit_expr(rhs, fn)
            out.append(f"{pad}dep_set_index2({base_code}, {self.own_of(ic, it)}, "
                       f"{self.own_of(c, t)});")
            return

    # ---------------- function emission ----------------
    def emit_user_function(self, fn, out, force_name=None, force_void=False):
        name = force_name or self.mangle_fn(fn.name)
        ret = "void" if (fn.ret == "void" or force_void) else CTYPE[fn.ret]
        params = ", ".join(f"{CTYPE[fn.ptypes[p]]} P_{p}" for p in fn.params) or "void"
        out.append(f"static {ret} {name}({params}) {{")
        for lname, lt in sorted(fn.local_types.items()):
            sym = "L_" + lname
            if lt == "num":
                out.append(f"    double {sym} = 0;")
            elif lt == "bool":
                out.append(f"    int {sym} = 0;")
            elif lt == "unk":
                out.append(f"    DEPValue {sym} = dep_nothing();")
            elif fn.reads_before.get(lname):
                init = {"text": 'dep_str_new("", 0)', "list": "dep_list_new()",
                        "map": "dep_map_new()"}.get(lt, "dep_nothing()")
                out.append(f"    {CTYPE[lt]} {sym} = {init};")
            else:
                out.append(f"    {CTYPE[lt]} {sym} = NULL;")
        # epilogue releases
        rel = []
        for lname, lt in sorted(fn.local_types.items()):
            if lt == "text":
                rel.append(f"dep_release_s(L_{lname});")
            elif lt == "list":
                rel.append(f"dep_release_l(L_{lname});")
            elif lt == "map":
                rel.append(f"dep_release_m(L_{lname});")
            elif lt == "unk":
                rel.append(f"dep_release(L_{lname});")
        for p in fn.params:
            pt = fn.ptypes[p]
            if pt == "text":
                rel.append(f"dep_release_s(P_{p});")
            elif pt == "list":
                rel.append(f"dep_release_l(P_{p});")
            elif pt == "map":
                rel.append(f"dep_release_m(P_{p});")
            elif pt == "unk":
                rel.append(f"dep_release(P_{p});")
        fn.epilogue = " ".join(rel) if rel else ";"
        body = []
        self.emit_stmts(fn.body, fn, body, 1)
        out.extend(body)
        out.append(f"    {fn.epilogue}")
        if ret == "void":
            out.append("}")
        else:
            rv = {"num": "0", "bool": "0", "text": 'dep_str_new("", 0)',
                  "list": "dep_list_new()", "map": "dep_map_new()",
                  "unk": "dep_nothing()"}[fn.ret]
            out.append(f"    return {rv};")
            out.append("}")

    # ---------------- top level ----------------
    def compile(self):
        self.analyze()
        self.btn_ids = {}
        out = []
        out.append("/* Generated by the DeadEnd compiler (dec). Do not edit. */")
        out.append("#include \"dep_runtime.h\"")
        out.append("#include \"motionkit.h\"")
        if self.kit:
            out.append("#include \"gamekit.h\"")
            out.append("#include \"appkit.h\"")
        out.append("")
        out.append(PRELUDE)
        # string literal slots
        for s, slot in self.strlits.items():
            out.append(f"static DEPStr *{slot};")
        out.append("")
        # forward declarations
        for fn in self.fns.values():
            ret = "void" if fn.ret == "void" else CTYPE[fn.ret]
            params = ", ".join(f"{CTYPE[fn.ptypes[p]]} P_{p}" for p in fn.params) or "void"
            out.append(f"static {ret} {self.mangle_fn(fn.name)}({params});")
        hid = 0
        handler_decls = []
        for (kind, arg), h in self.handlers_by.items():
            if kind == "game_starts":
                hname = "H_game_starts"
            elif kind == "frame":
                hname = "H_frame"
            else:
                hname = f"H_btn_{hid}"
                self.btn_ids[arg] = hid
                hid += 1
            h.hname = hname
            handler_decls.append(hname)
            out.append(f"static void {hname}(void);")
        out.append("")
        # globals
        ginit_lines = []
        for name, t in sorted(self.gtypes.items()):
            sym = "G_" + name
            if t == "num":
                out.append(f"static double {sym} = 0;")
            elif t == "bool":
                out.append(f"static int {sym} = 0;")
            elif t == "unk":
                out.append(f"static DEPValue {sym};")  # zero = nothing
            else:
                out.append(f"static {CTYPE[t]} {sym} = NULL;")
                if self.global_reads_before.get(name):
                    init = {"text": 'dep_str_new("", 0)', "list": "dep_list_new()",
                            "map": "dep_map_new()"}[t]
                    ginit_lines.append(f"    {sym} = {init};")
        out.append("")
        # user functions
        for fn in self.fns.values():
            self.emit_user_function(fn, out)
            out.append("")
        # motion kit read/write bindings (one pair per animated target)
        for sid, base, chain, last, gt in self.motion_binds:
            if last is None:
                out.append(f"static double dep_m_from_{sid}(void) {{")
                if gt == "unk":
                    out.append(f"    return dep_as_num(G_{base});")
                else:
                    out.append(f"    return G_{base};")
                out.append("}")
                out.append(f"static void dep_m_write_{sid}(double v) {{")
                if gt == "unk":
                    out.append(f"    dep_release(G_{base}); G_{base} = dep_n(v);")
                elif gt == "bool":
                    out.append(f"    G_{base} = (v != 0);")
                else:
                    out.append(f"    G_{base} = v;")
                out.append("}")
            else:
                def chain_lines():
                    lines = []
                    own = (f"dep_own(dep_vm(G_{base}))" if gt == "map"
                           else f"dep_own(G_{base})")
                    lines.append(f"    DEPValue b0 = {own};")
                    prev = "b0"
                    for i, f in enumerate(chain):
                        cur = f"b{i + 1}"
                        lines.append(f"    DEPValue {cur} = dep_nothing();")
                        lines.append(f"    if ({prev}.tag == DEP_T_MAP) "
                                     f"{cur} = dep_field({prev}, {c_str(f)});")
                        lines.append(f"    dep_release({prev});")
                        prev = cur
                    return lines, prev
                lines, prev = chain_lines()
                out.append(f"static double dep_m_from_{sid}(void) {{")
                out.extend(lines)
                out.append("    double r = 0.0;")
                # bug fix (39): the start value of `move ball.x toward ...`
                # must be read from the field itself, not from the map that
                # holds it (a map is never a number, so every map-field
                # animation used to start from 0)
                out.append(f"    if ({prev}.tag == DEP_T_MAP) {{")
                out.append(f"        DEPValue f = dep_field({prev}, {c_str(last)});")
                out.append("        if (f.tag == DEP_T_NUM) r = f.as.n;")
                out.append("        dep_release(f);")
                out.append("    }")
                out.append(f"    dep_release({prev});")
                out.append("    return r;")
                out.append("}")
                lines, prev = chain_lines()
                out.append(f"static void dep_m_write_{sid}(double v) {{")
                out.extend(lines)
                out.append(f"    if ({prev}.tag == DEP_T_MAP) "
                           f"dep_map_set_field({prev}.as.m, {c_str(last)}, dep_n(v));")
                out.append(f"    dep_release({prev});")
                out.append("}")
        # handlers (H_frame sets a flag so 'every N seconds' can validate)
        for (kind, arg), h in self.handlers_by.items():
            self._in_frame = (kind == "frame")
            self.emit_user_function(h, out, force_name=h.hname, force_void=True)
            self._in_frame = False
            out.append("")
        # main
        out.append("int dep_main(void) {")
        out.extend(ginit_lines)
        for sid, base, chain, last, gt in self.motion_binds:
            out.append(f"    dep_m_bind({sid}, dep_m_from_{sid}, dep_m_write_{sid});")
        epilogue = []
        for name, t in sorted(self.gtypes.items()):
            if t == "text":
                epilogue.append(f"dep_release_s(G_{name});")
            elif t == "list":
                epilogue.append(f"dep_release_l(G_{name});")
            elif t == "map":
                epilogue.append(f"dep_release_m(G_{name});")
            elif t == "unk":
                epilogue.append(f"dep_release(G_{name});")
        body = []
        self.emit_stmts(self.main_body, None, body, 1)
        out.extend(body)
        if epilogue:
            out.append("    " + " ".join(epilogue))
        out.append("    return 0;")
        out.append("}")
        # bug fix (40): refuse to build a program that would silently do
        # nothing: kit handlers/widgets registered but `run` never written
        if self.kit == "game" and not self.ran["game"] and \
                (self.saw_frame or self.saw_start):
            raise DepError(
                "your program sets up the game but never starts it -- write "
                "`run game` as the last line. `run game` opens the window "
                "and runs 'every frame'; without it the program ends at once "
                "and no window ever appears", 0)
        if self.kit == "app" and not self.ran["app"] and \
                (self.saw_frame or self.saw_click or self.saw_widget):
            raise DepError(
                "your program builds the app but never starts it -- write "
                "`run app` as the last line. `run app` opens the window and "
                "shows your widgets; without it the program ends at once and "
                "no window ever appears", 0)
        return "\n".join(out) + "\n"


PRELUDE = r"""
#define DEP_UNUSED __attribute__((unused))

static DEP_UNUSED DEPValue dep_add2(DEPValue a, DEPValue b){ DEPValue r = dep_add(a,b); dep_release(a); dep_release(b); return r; }
static DEP_UNUSED DEPValue dep_sub2(DEPValue a, DEPValue b){ DEPValue r = dep_sub(a,b); dep_release(a); dep_release(b); return r; }
static DEP_UNUSED DEPValue dep_mul2(DEPValue a, DEPValue b){ DEPValue r = dep_mul(a,b); dep_release(a); dep_release(b); return r; }
static DEP_UNUSED DEPValue dep_div2(DEPValue a, DEPValue b){ DEPValue r = dep_div(a,b); dep_release(a); dep_release(b); return r; }
static DEP_UNUSED DEPValue dep_mod2(DEPValue a, DEPValue b){ DEPValue r = dep_mod(a,b); dep_release(a); dep_release(b); return r; }
static DEP_UNUSED DEPValue dep_neg2(DEPValue a){ DEPValue r = dep_neg(a); dep_release(a); return r; }
static DEP_UNUSED int dep_eq2(DEPValue a, DEPValue b){ int r = dep_eq(a,b); dep_release(a); dep_release(b); return r; }
static DEP_UNUSED int dep_neq2(DEPValue a, DEPValue b){ int r = dep_eq(a,b); dep_release(a); dep_release(b); return !r; }
static DEP_UNUSED int dep_less2(DEPValue a, DEPValue b){ int r = dep_less(a,b); dep_release(a); dep_release(b); return r; }
static DEP_UNUSED int dep_has2(DEPValue c, DEPValue v){ int r = dep_has(c,v); dep_release(c); dep_release(v); return r; }
static DEP_UNUSED int dep_hasnot2(DEPValue c, DEPValue v){ int r = dep_has(c,v); dep_release(c); dep_release(v); return !r; }
static DEP_UNUSED int dep_truthy2(DEPValue v){ int r = dep_truthy(v); dep_release(v); return r; }
static DEP_UNUSED int dep_truthy_s2(DEPStr *s){ int r = s->len > 0; dep_release_s(s); return r; }
static DEP_UNUSED DEPValue dep_index2(DEPValue c, DEPValue i){ DEPValue r = dep_index(c,i); dep_release(c); dep_release(i); return r; }
static DEP_UNUSED DEPValue dep_field2(DEPValue m, const char *k){ DEPValue r = dep_field(m,k); dep_release(m); return r; }
/* dep_set_index takes ownership of i (a map stores the key value itself;
   for lists i is always a plain number), so i must NOT be released here. */
static DEP_UNUSED void dep_set_index2(DEPValue c, DEPValue i, DEPValue v){ dep_set_index(c,i,v); dep_release(c); }
static DEP_UNUSED void dep_setfield2(DEPValue m, const char *k, DEPValue v){ if (m.tag != DEP_T_MAP) dep_die("only maps have fields like .%s", k); dep_map_set_cstr(m.as.m, k, v); dep_release(m); }
static DEP_UNUSED void dep_print2(DEPValue v){ dep_print(v); dep_release(v); }
static DEP_UNUSED DEPStr *dep_ask2(DEPValue p){ const char *s = (p.tag == DEP_T_TEXT) ? p.as.s->chars : ""; DEPValue r = dep_ask(s); dep_release(p); return r.as.s; }
static DEP_UNUSED DEPStr *dep_text2(DEPValue v){ DEPValue r = dep_text_of(v); dep_release(v); return r.as.s; }
static DEP_UNUSED DEPValue dep_number2(DEPValue v){ DEPValue r = dep_number_of(v); dep_release(v); return r; }
static DEP_UNUSED DEPStr *dep_upper2(DEPValue v){ DEPValue r = dep_upper(v); dep_release(v); return r.as.s; }
static DEP_UNUSED DEPStr *dep_lower2(DEPValue v){ DEPValue r = dep_lower(v); dep_release(v); return r.as.s; }
static DEP_UNUSED DEPStr *dep_trim2(DEPValue v){ DEPValue r = dep_trim(v); dep_release(v); return r.as.s; }
static DEP_UNUSED DEPList *dep_split2(DEPValue s, DEPValue sep){ DEPValue r = dep_split(s,sep); dep_release(s); dep_release(sep); return r.as.l; }
static DEP_UNUSED DEPStr *dep_join2(DEPValue l, DEPValue sep){ DEPValue r = dep_join(l,sep); dep_release(l); dep_release(sep); return r.as.s; }
static DEP_UNUSED double dep_find2(DEPValue h, DEPValue n){ DEPValue r = dep_find(h,n); dep_release(h); dep_release(n); return (r.tag == DEP_T_NUM) ? r.as.n : 0; }
static DEP_UNUSED DEPStr *dep_replace2(DEPValue s, DEPValue a, DEPValue b){ DEPValue r = dep_replace(s,a,b); dep_release(s); dep_release(a); dep_release(b); return r.as.s; }
static DEP_UNUSED double dep_count_of(DEPValue v){ double r = (double)dep_count(v); dep_release(v); return r; }
static DEP_UNUSED DEPList *dep_keys_of(DEPValue v){ if (v.tag != DEP_T_MAP) dep_die("keys of needs a map, got %s", dep_typename(v)); DEPList *r = dep_map_keys(v.as.m); dep_release(v); return r; }
static DEP_UNUSED DEPValue dep_first_of(DEPValue v){ DEPValue r = dep_first(v); dep_release(v); return r; }
static DEP_UNUSED DEPValue dep_last_of(DEPValue v){ DEPValue r = dep_last(v); dep_release(v); return r; }
static DEP_UNUSED DEPValue dep_load2(DEPValue p){ DEPValue r = (p.tag == DEP_T_TEXT) ? dep_load_file(p.as.s->chars) : dep_nothing(); dep_release(p); return r; }
static DEP_UNUSED void dep_save2(DEPValue p, DEPValue v){ if (p.tag != DEP_T_TEXT) dep_die("save needs a file name in text"); dep_save_file(p.as.s->chars, v); dep_release(p); dep_release(v); }
static DEP_UNUSED int dep_exists2(DEPValue p){ int r = 0; if (p.tag == DEP_T_TEXT) { DEPValue e = dep_exists_file(p.as.s->chars); r = dep_truthy(e); } dep_release(p); return r; }
static DEP_UNUSED double dep_random1(double hi){ return dep_random(1, hi); }
static DEP_UNUSED void dep_push2(DEPValue c, DEPValue v){ DEPList *l = dep_as_list(c); dep_list_push(l, v); dep_release_l(l); }
static DEP_UNUSED void dep_remove_at2(DEPValue c, DEPValue i){ DEPList *l = dep_as_list(c); dep_list_remove_at(l, dep_as_num(i)); dep_release_l(l); }
static DEP_UNUSED void dep_remove_from2(DEPValue c, DEPValue v){ if (c.tag == DEP_T_MAP) { dep_map_delete(c.as.m, v); dep_release(c); dep_release(v); return; } DEPList *l = dep_as_list(c); dep_list_remove_value(l, v); dep_release_l(l); dep_release(v); }
static DEP_UNUSED void dep_sort2(DEPValue c){ DEPList *l = dep_as_list(c); dep_list_sort(l); dep_release_l(l); }
static DEP_UNUSED void dep_reverse2(DEPValue c){ DEPList *l = dep_as_list(c); dep_list_reverse(l); dep_release_l(l); }
static DEP_UNUSED void dep_shuffle2(DEPValue c){ DEPList *l = dep_as_list(c); dep_list_shuffle(l); dep_release_l(l); }
static DEP_UNUSED DEPStr *dep_lit(DEPStr **slot, const char *s){ if (!*slot){ *slot = dep_str_new(s, (long)strlen(s)); } return dep_own_s(*slot); }
"""


def compile_source(src):
    from dep_parse import parse
    ast = parse(src)
    return Compiler(ast).compile()
