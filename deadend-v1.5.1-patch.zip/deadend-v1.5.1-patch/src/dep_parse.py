"""DeadEnd lexer + parser.
Turns .dep source into an AST of tuples:
  ('num', value) ('text', s) ('bool', b) ('nothing',)
  ('list', [exprs]) ('map', [(keyexpr, valexpr)])
  ('name', name) ('field', expr, name) ('index', expr, expr)
  ('call', name, [args], line)
  ('bin', op, a, b) ('un', op, a)
  ('is', a, b) ('isnot', a, b) ('cmp', op, a, b) ('has', a, b) ('hasnot', a, b)

Statements:
  ('set', target, expr) ('change', target, expr)
  ('print', [exprs])
  ('if', [(cond, [stmts])...], [else_stmts])
  ('repeat_n', expr, [stmts]) ('repeat_for', var, a, b, step, [stmts])
  ('repeat_forever', [stmts]) ('while', cond, [stmts])
  ('foreach', var, expr, [stmts])
  ('func', name, [params], [stmts], line)
  ('return', expr_or_None) ('break',) ('continue',) ('exit',)
  ('callstmt', name, [args], line)
  ('use', 'game'|'app')
  ('make', kind, title, {options}, line)
  ('when', kind, arg, [stmts], line)   # kind: 'game_starts' | 'button'
  ('every', [stmts], line)
  ('run', 'game'|'app', line)
  ('add', widget, name, x, y, w_or_None, h_or_None, line)
  ('setwidget', widget, name, expr, line)

Motion kit (v1.4.0):
  ('mmove', target, value_expr, opts, line)      opts: feel dur dur_ms from_expr
  ('mspring', target, value_expr, opts, line)           delay delay_ms forever
  ('mtl_make', name, line)                              repeat pingpong together
  ('mtl_add', tlname, inner, line)               inner: mmove/mspring/mui/mwait
  ('mtl_play', name, repeat_or_None, forever, line)
  ('mtl_pause', name, line) ('mtl_resume', name, line) ('mtl_stop', name, line)
  ('mstop', target_or_None, line)                None = stop every animation
  ('mui', op, widget, name, opts, line)          op: pop_in pop_out fade_in...
  ('mwait', dur, ms, line)
  ('mfx', op, opts, line)                        op: shake flash fadeto fadefrom zoom reset
  ('mpart', op, payload, line)                   op: burst rain snow clear
  ('madvance', expr, ms, line)

target := ('tname', name) | ('tfield', target, name) | ('tindex', target, expr)
"""
import re

KEYWORDS = {
    "set", "to", "print", "if", "then", "else", "end", "repeat", "times",
    "forever", "with", "from", "by", "while", "function", "return", "break",
    "continue", "for", "each", "in", "and", "or", "not", "is", "more", "than",
    "greater", "less", "fewer", "bigger", "smaller", "of", "at", "least", "most",
    "has", "yes", "no", "nothing", "true", "false", "use", "game", "app",
    "kit", "make", "window", "when", "starts", "every", "frame", "run",
    "change", "exit", "button", "clicked", "add", "remove", "item",
}

SYM2 = [">=", "<="]
SYM1 = ["+", "-", "*", "/", "%", ">", "<", "(", ")", "[", "]", "{", "}",
        ",", ".", ":", "#"]

NUM_RE = re.compile(r"\d+(\.\d+)?([eE][+-]?\d+)?")
NAME_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")

# keywords that may still be used as function names in call position
BARE_CALL_KW = {"add", "remove", "item", "of", "at", "times", "by", "from",
                "with", "each", "change", "make", "run", "use", "exit",
                "forever", "button", "window", "game", "app", "when",
                "every", "frame", "kit", "starts", "clicked", "print"}

# built-in math words that accept a bare negative first argument, so the
# documented forms work: `abs -5`, `min -3, 9`, `random -1, 6`.
# (Restricted to built-ins on purpose: for a plain name, `x - 5` must stay
# subtraction, and for a zero-value built-in like `clock`, `clock - 5`
# means clock() - 5.)
NEG_ARG_BUILTINS = {"abs", "floor", "ceiling", "round", "sqrt", "sin",
                    "cos", "tan", "atan", "power", "min", "max", "random"}

# built-ins whose documented form takes SEVERAL comma-separated bare
# arguments (min 3, 9 -- power 2, 10 -- random 1, 6 -- replace a, b, c...).
# Inside a statement's argument list (`print min 3, 9`) these must keep
# their own commas instead of handing them to the statement.
COMMA_ARG_BUILTINS = {"min", "max", "power", "random", "find", "replace",
                      "split", "join"}

# ---- motion kit (v1.4.0) ----
# statement words are matched as NAME *or* KW tokens, so nothing new becomes
# reserved: a variable named `move` still works everywhere except at the head
# of a line that really looks like an animation sentence.
MOTION_STMT_WORDS = {
    "move", "spring", "stop", "play", "pause", "resume", "advance",
    "burst", "rain", "snow", "shake", "fade", "flash", "zoom", "reset",
    "pop", "slide", "glide", "bump", "wiggle",
}
MOTION_PART_KINDS = {"sparks", "confetti", "smoke", "stars", "fire",
                     "bubbles", "hearts", "particles"}
MOTION_WIDGETS = {"title", "label", "button", "field", "checkbox",
                  "slider", "image", "panel"}
MOTION_DUR_UNITS = {"second", "seconds", "millisecond", "milliseconds", "ms"}
# words that end the *value* of a move/spring (so `move x toward home lasting
# 2 seconds` does not read `home lasting...` as a call)
MOTION_VALUE_STOP = {"lasting", "feeling", "waiting", "starting",
                     "reversing", "repeating", "together", "with"}


class _NotMotion(Exception):
    """internal: the line only looked like a motion sentence -- fall back."""


class DepError(Exception):
    def __init__(self, msg, line):
        super().__init__(f"line {line}: {msg}")
        self.line = line


class Token:
    __slots__ = ("kind", "val", "line")

    def __init__(self, kind, val, line):
        self.kind = kind    # NAME KW NUM TEXT SYM NEWLINE EOF
        self.val = val
        self.line = line

    def __repr__(self):
        return f"{self.kind}:{self.val!r}@{self.line}"


ESCAPES = {"n": "\n", "t": "\t", "r": "\r", '"': '"', "\\": "\\", "0": "\0"}


def tokenize(src):
    toks = []
    i, n = 0, len(src)
    line = 1
    depth = 0  # () [] {} nesting: newlines suppressed inside
    while i < n:
        c = src[i]
        if c == "\n":
            if depth == 0:
                if toks and toks[-1].kind != "NEWLINE":
                    toks.append(Token("NEWLINE", "\n", line))
            line += 1
            i += 1
            continue
        if c in " \t\r":
            i += 1
            continue
        if c == "#":
            while i < n and src[i] != "\n":
                i += 1
            continue
        if c == '"':
            j = i + 1
            buf = []
            while j < n and src[j] != '"':
                if src[j] == "\\":
                    if j + 1 >= n:
                        raise DepError("unfinished text literal", line)
                    esc = src[j + 1]
                    if esc not in ESCAPES:
                        raise DepError(f"unknown escape \\{esc} in text", line)
                    buf.append(ESCAPES[esc])
                    j += 2
                elif src[j] == "\n":
                    raise DepError("text literal not closed before end of line "
                                   "(texts must stay on one line)", line)
                else:
                    buf.append(src[j])
                    j += 1
            if j >= n:
                raise DepError("text literal not closed", line)
            toks.append(Token("TEXT", "".join(buf), line))
            i = j + 1
            continue
        if c.isdigit():
            m = NUM_RE.match(src, i)
            toks.append(Token("NUM", float(m.group(0)), line))
            i = m.end()
            continue
        if c.isalpha() or c == "_":
            m = NAME_RE.match(src, i)
            w = m.group(0)
            toks.append(Token("KW" if w in KEYWORDS else "NAME", w, line))
            i = m.end()
            continue
        two = src[i:i + 2]
        if two in SYM2:
            toks.append(Token("SYM", two, line))
            i += 2
            continue
        if c in SYM1:
            if c in "([{":
                depth += 1
            elif c in ")]}":
                depth = max(0, depth - 1)
            toks.append(Token("SYM", c, line))
            i += 1
            continue
        raise DepError(f"unexpected character {c!r}", line)
    toks.append(Token("NEWLINE", "\n", line))
    toks.append(Token("EOF", None, line))
    return toks


class Parser:
    def __init__(self, toks):
        self.toks = toks
        self.pos = 0
        self._nested_arg = False   # True while parsing args of a statement call
        self._motion_stop = set()  # words that end a move/spring value

    # ---- token helpers ----
    def peek(self, off=0):
        return self.toks[min(self.pos + off, len(self.toks) - 1)]

    def next(self):
        t = self.toks[self.pos]
        if t.kind != "EOF":
            self.pos += 1
        return t

    def at_kw(self, *words):
        t = self.peek()
        return t.kind == "KW" and t.val in words

    def _at_word(self, off, *words):
        """a keyword OR a plain name with one of these values (motion kit)."""
        t = self.peek(off)
        return t.kind in ("KW", "NAME") and t.val in words

    def at_sym(self, s):
        t = self.peek()
        return t.kind == "SYM" and t.val == s

    def eat_kw(self, word, what=""):
        t = self.next()
        if t.kind != "KW" or t.val != word:
            raise DepError(f"expected '{word}' {what} but found "
                           f"'{self._show(t)}'", t.line)
        return t

    def eat_sym(self, s, what=""):
        t = self.next()
        if t.kind != "SYM" or t.val != s:
            raise DepError(f"expected '{s}' {what} but found "
                           f"'{self._show(t)}'", t.line)
        return t

    def eat_name(self, what="a name"):
        t = self.next()
        if t.kind != "NAME":
            raise DepError(f"expected {what} but found '{self._show(t)}'", t.line)
        return t.val

    def skip_newlines(self):
        while self.peek().kind == "NEWLINE":
            self.next()

    def _show(self, t):
        if t.kind == "EOF":
            return "end of file"
        if t.kind == "NEWLINE":
            return "end of line"
        return str(t.val)

    def end_of_stmt(self):
        """True when current token can end a statement."""
        t = self.peek()
        return (t.kind in ("NEWLINE", "EOF") or
                (t.kind == "KW" and t.val in ("end", "else")))

    # ---- program ----
    def parse_program(self):
        stmts = []
        self.skip_newlines()
        while self.peek().kind != "EOF":
            stmts.append(self.parse_stmt())
            self.skip_newlines()
        return stmts

    def parse_block(self):
        """Newline-terminated statement list ended by end/else (not consumed)."""
        stmts = []
        self.skip_newlines()
        while True:
            t = self.peek()
            if t.kind == "EOF":
                raise DepError(f"missing 'end' before end of file", t.line)
            if t.kind == "KW" and t.val in ("end", "else"):
                return stmts
            stmts.append(self.parse_stmt())
            self.skip_newlines()

    # ---- statements ----
    def parse_stmt(self):
        t = self.peek()
        if t.kind == "KW":
            v = t.val
            if v == "set":
                return self.parse_set()
            if v == "change":
                return self.parse_change()
            if v == "print":
                return self.parse_print()
            if v == "if":
                return self.parse_if()
            if v == "repeat":
                return self.parse_repeat()
            if v == "while":
                return self.parse_while()
            if v == "for":
                return self.parse_foreach()
            if v == "function":
                return self.parse_func()
            if v == "return":
                self.next()
                if self.end_of_stmt():
                    return ("return", None, t.line)
                return ("return", self.parse_expr(), t.line)
            if v == "break":
                self.next()
                return ("break", t.line)
            if v == "continue":
                self.next()
                return ("continue", t.line)
            if v == "exit":
                self.next()
                return ("exit", t.line)
            if v == "use":
                return self.parse_use()
            if v == "make":
                return self.parse_make()
            if v == "when":
                return self.parse_when()
            if v == "every":
                self.next()
                if self.at_kw("frame"):
                    self.next()
                    body = self.parse_block()
                    self.eat_kw("end", "to close 'every frame'")
                    return ("every", body, t.line)
                # every 2 seconds ... end / every 500 milliseconds ... end
                n = self.parse_add()
                if not self._at_word(0, "second", "seconds",
                                     "millisecond", "milliseconds", "ms"):
                    raise DepError("after 'every' write 'frame' or a time, "
                                   "like 'every 2 seconds'", self.peek().line)
                unit = self.next().val
                ms = unit in ("millisecond", "milliseconds", "ms")
                body = self.parse_block()
                self.eat_kw("end", "to close 'every ... seconds'")
                return ("everytime", n, ms, body, t.line)
            if v == "run":
                self.next()
                if self.at_kw("game"):
                    self.next()
                    return ("run", "game", t.line)
                if self.at_kw("app"):
                    self.next()
                    return ("run", "app", t.line)
                raise DepError("after 'run' write 'game' or 'app'", t.line)
            if v == "add":
                return self.parse_add_stmt()
            if v == "remove":
                return self.parse_remove()
            raise DepError(f"'{v}' cannot start a statement here", t.line)
        if t.kind == "NAME":
            # canvas sentences (paint/show/clear/save canvas ...) -- 'paint'
            # has its own shape ('paint on canvas'), the others start with
            # the word 'canvas'. Tried before motion words, because motion's
            # 'clear particles' parser would otherwise eat the line.
            p1, p2 = self.peek(1), self.peek(2)
            if t.val == "paint" and self._at_word(1, "on") and \
                    p2.kind == "NAME" and p2.val == "canvas":
                return self.parse_canvas_paint()
            if t.val in ("show", "clear", "save") and \
                    p1.kind == "NAME" and p1.val == "canvas":
                save = self.pos
                try:
                    return self.parse_canvas_stmt(t.val)
                except _NotMotion:
                    self.pos = save
            # camera sentences (pan camera / follow camera / release camera)
            if t.val in ("pan", "follow", "release") and \
                    p1.kind == "NAME" and p1.val == "camera":
                return self.parse_camera_stmt(t.val)
            # motion kit sentences (move/spring/burst/...) -- only when the
            # line really matches the grammar, else it stays a normal call
            if t.val in MOTION_STMT_WORDS or (t.val == "clear" and
                    self.peek(1).kind == "NAME" and self.peek(1).val == "particles"):
                save = self.pos
                try:
                    return self.parse_motion_stmt(t.val)
                except _NotMotion:
                    self.pos = save
            return self.parse_callstmt()
        raise DepError(f"unexpected {self._show(t)}", t.line)

    # ================= canvas kit (v1.5.1) =================

    def parse_canvas_paint(self):
        """paint on canvas "name" ... end"""
        t = self.next()                  # the word 'paint'
        self.next()                      # 'on'
        self.next()                      # 'canvas'
        nt = self.next()
        if nt.kind != "TEXT":
            raise DepError("after 'paint on canvas' write the canvas name in "
                           f"quotes, like paint on canvas \"art\"", nt.line)
        body = self.parse_block()
        self.eat_kw("end", "to close 'paint on canvas'")
        return ("canvas_paint", ("text", nt.val), body, t.line)

    def parse_canvas_stmt(self, word):
        """show / clear / save canvas sentences"""
        t = self.next()                  # show / clear / save
        self.next()                      # the word 'canvas'
        nt = self.next()
        if nt.kind != "TEXT":
            raise _NotMotion()
        name = ("text", nt.val)
        if word == "show":
            x = y = w = h = None
            if self.at_kw("at"):
                self.next()
                x = self.parse_add()
                self.eat_sym(",", "between x and y in 'show canvas ... at x, y'")
                y = self.parse_add()
                if self.at_kw("with"):
                    self.next()
                    kt = self.next()
                    if not (kt.kind == "NAME" and kt.val == "size"):
                        raise DepError("after 'with' write 'size'", kt.line)
                    w = self.parse_add()
                    self.eat_sym(",", "between width and height in "
                                  "'with size w, h'")
                    h = self.parse_add()
            return ("canvas_show", name, x, y, w, h, t.line)
        if word == "clear":
            if not self.at_kw("with"):
                raise DepError("after 'clear canvas ...' write "
                               "'with \"color\"'", self.peek().line)
            self.next()
            col = self.parse_add()
            return ("canvas_clear", name, col, t.line)
        # save
        if not self.at_kw("to"):
            raise DepError("after 'save canvas ...' write "
                           "'to \"file.png\"'", self.peek().line)
        self.next()
        f = self.parse_add()
        return ("canvas_save", name, f, t.line)

    # ================= camera (v1.5.1) =================

    def parse_camera_stmt(self, word):
        """pan camera to/by x, y [lasting ...] [feeling ...]
           follow camera on x, y [with speed N]
           release camera"""
        t = self.next()                  # pan / follow / release
        self.next()                      # the word 'camera'
        if word == "release":
            return ("cam_release", t.line)
        if word == "pan":
            mode = "to"
            if self.at_kw("to") or self._at_word(0, "to"):
                self.next()
            elif self.at_kw("by") or self._at_word(0, "by"):
                self.next()
                mode = "by"
            else:
                raise DepError("after 'pan camera' write 'to x, y' or "
                               "'by dx, dy'", self.peek().line)
            x = self.parse_add()
            self.eat_sym(",", "between x and y in 'pan camera ...'")
            y = self.parse_add()
            dur = None
            dur_ms = False
            feel = None
            while True:
                if self._at_word(0, "lasting"):
                    self.next()
                    dur = self.parse_add()
                    dur_ms = self._motion_unit()
                elif self._at_word(0, "feeling"):
                    self.next()
                    feel = self._motion_feel_word()
                else:
                    break
            return ("cam_pan", mode, x, y, dur, dur_ms, feel, t.line)
        # follow camera on x, y [with speed N]
        if not self._at_word(0, "on"):
            raise DepError("after 'follow camera' write 'on x, y'",
                           self.peek().line)
        self.next()
        x = self.parse_add()
        self.eat_sym(",", "between x and y in 'follow camera on x, y'")
        y = self.parse_add()
        speed = None
        if self.at_kw("with"):
            self.next()
            kt = self.next()
            if not (kt.kind == "NAME" and kt.val == "speed"):
                raise DepError("after 'with' write 'speed'", kt.line)
            speed = self.parse_add()
        return ("cam_follow", x, y, speed, t.line)

    def parse_set(self):
        t = self.eat_kw("set")
        # widget set: set label "x" to ... / set field "x" to ...
        if (self.peek().kind == "NAME" and self.peek().val in ("label", "field", "checkbox", "slider")
                and self.peek(1).kind == "TEXT" and self.peek(2).kind == "KW"
                and self.peek(2).val == "to"):
            widget = self.next().val
            name = self.next().val
            self.next()  # to
            return ("setwidget", widget, name, self.parse_expr(), t.line)
        target = self.parse_target()
        self.eat_kw("to", f"after 'set {self._target_str(target)}'")
        expr = self.parse_expr()
        return ("set", target, expr, t.line)

    def parse_change(self):
        t = self.eat_kw("change")
        target = self.parse_target()
        self.eat_kw("by", "in 'change ... by ...'")
        expr = self.parse_expr()
        return ("change", target, expr, t.line)

    def parse_print(self):
        t = self.eat_kw("print")
        args = [self._parse_stmt_arg()]
        while self.at_sym(",") or self.at_kw("and"):
            self.next()
            args.append(self._parse_stmt_arg())
        return ("print", args, t.line)

    def _parse_stmt_arg(self):
        """One argument of a statement-level call (nested bare calls stay single-value)."""
        self._nested_arg = True
        try:
            return self.parse_add()
        finally:
            self._nested_arg = False

    def parse_if(self):
        t = self.eat_kw("if")
        branches = []
        cond = self.parse_expr()
        if self.at_kw("then"):
            self.next()
            one = [self.parse_stmt()]
            branches.append((cond, one))
            return ("if", branches, [], t.line)
        body = self.parse_block()
        branches.append((cond, body))
        els = []
        while True:
            if self.at_kw("end"):
                self.next()
                break
            if self.at_kw("else"):
                self.next()
                if self.at_kw("if"):
                    self.next()
                    c2 = self.parse_expr()
                    b2 = self.parse_block()
                    branches.append((c2, b2))
                    continue
                els = self.parse_block()
                self.eat_kw("end", "to close 'else'")
                break
            t = self.peek()
            raise DepError(f"expected 'end' or 'else' but found "
                           f"'{self._show(t)}'", t.line)
        return ("if", branches, els, t.line)

    def parse_repeat(self):
        t = self.eat_kw("repeat")
        if self.at_kw("forever"):
            self.next()
            body = self.parse_block()
            self.eat_kw("end", "to close 'repeat forever'")
            return ("repeat_forever", body, t.line)
        if self.at_kw("with"):
            self.next()
            var = self.eat_name("a counter name after 'repeat with'")
            self.eat_kw("from", "in 'repeat with ... from ...'")
            a = self.parse_expr()
            self.eat_kw("to", "in 'repeat with ... from ... to ...'")
            b = self.parse_expr()
            step = None
            if self.at_kw("by"):
                self.next()
                step = self.parse_expr()
            body = self.parse_block()
            self.eat_kw("end", "to close 'repeat with'")
            return ("repeat_for", var, a, b, step, body, t.line)
        count = self.parse_expr()
        self.eat_kw("times", "after the number in 'repeat ... times'")
        body = self.parse_block()
        self.eat_kw("end", "to close 'repeat'")
        return ("repeat_n", count, body, t.line)

    def parse_while(self):
        t = self.eat_kw("while")
        cond = self.parse_expr()
        body = self.parse_block()
        self.eat_kw("end", "to close 'while'")
        return ("while", cond, body, t.line)

    def parse_foreach(self):
        t = self.eat_kw("for")
        self.eat_kw("each", "after 'for'")
        var = self.eat_name("an item name after 'for each'")
        self.eat_kw("in", "in 'for each ... in ...'")
        coll = self.parse_expr()
        body = self.parse_block()
        self.eat_kw("end", "to close 'for each'")
        return ("foreach", var, coll, body, t.line)

    def parse_func(self):
        t = self.eat_kw("function")
        nt = self.next()
        if nt.kind not in ("NAME", "KW"):
            raise DepError(f"expected a function name but found "
                           f"'{self._show(nt)}'", nt.line)
        name = nt.val
        params = []
        if self.at_kw("with"):
            self.next()
            params.append(self.eat_name("a parameter name"))
            while self.at_kw("and"):
                self.next()
                params.append(self.eat_name("a parameter name"))
        body = self.parse_block()
        self.eat_kw("end", f"to close 'function {name}'")
        return ("func", name, params, body, t.line)

    def parse_use(self):
        t = self.eat_kw("use")
        if self.at_kw("game"):
            self.next()
            self.eat_kw("kit", "after 'use game'")
            return ("use", "game")
        if self.at_kw("app"):
            self.next()
            self.eat_kw("kit", "after 'use app'")
            return ("use", "app")
        raise DepError("after 'use' write 'game kit' or 'app kit'", t.line)

    MAKE_OPTS = ("width", "height", "fps", "fullscreen")

    def parse_make(self):
        t = self.eat_kw("make")
        if self._at_word(0, "timeline"):
            self.next()
            nt = self.next()
            if nt.kind != "TEXT":
                raise DepError("after 'make timeline' write its name in quotes",
                               nt.line)
            return ("mtl_make", nt.val, t.line)
        if self.at_kw("game"):
            self.next()
            kind = "game"
        elif self.at_kw("window"):
            self.next()
            kind = "window"
        else:
            raise DepError("after 'make' write 'game' or 'window'", t.line)
        title = self.parse_expr()
        opts = {}
        if self.at_kw("with"):
            self.next()
            while True:
                key = self.next()
                if key.kind != "NAME" or key.val not in self.MAKE_OPTS:
                    raise DepError(f"unknown option '{self._show(key)}' "
                                   f"(options: width, height, fps, fullscreen)", key.line)
                opts[key.val] = self.parse_add()
                if self.at_kw("and"):
                    self.next()
                    continue
                break
        return ("make", kind, title, opts, t.line)

    def parse_when(self):
        t = self.eat_kw("when")
        if self.at_kw("game"):
            self.next()
            self.eat_kw("starts", "after 'when game'")
            body = self.parse_block()
            self.eat_kw("end", "to close 'when game starts'")
            return ("when", "game_starts", None, body, t.line)
        if self.at_kw("button"):
            self.next()
            bt = self.next()
            if bt.kind != "TEXT":
                raise DepError("after 'button' write its text in quotes", bt.line)
            self.eat_kw("is", "in 'when button ... is clicked'")
            self.eat_kw("clicked", "in 'when button ... is clicked'")
            body = self.parse_block()
            self.eat_kw("end", "to close 'when button'")
            return ("when", "button", bt.val, body, t.line)
        raise DepError("after 'when' write 'game starts' or 'button \"...\" is clicked'", t.line)

    def parse_add_stmt(self):
        t = self.eat_kw("add")
        # timeline items: add move/spring/wait/pop/... to timeline "name"
        pk = self.peek()
        if pk.kind in ("NAME", "KW") and pk.val in (
                "move", "spring", "wait", "pop", "slide", "fade", "glide",
                "bump", "wiggle", "shake"):
            save = self.pos
            try:
                inner = self.parse_timeline_item(pk.val)
                self.eat_kw("to", "in 'add ... to timeline ...'")
                tt = self.next()
                if not (tt.kind in ("KW", "NAME") and tt.val == "timeline"):
                    raise DepError("after 'add' write 'to timeline \"name\"'",
                                   tt.line)
                nt = self.next()
                if nt.kind != "TEXT":
                    raise DepError("after 'timeline' write its name in quotes",
                                   nt.line)
                # "... to timeline "name" together" -- the friendly word order
                if self._at_word(0, "together"):
                    self.next()
                    if inner[0] in ("mmove", "mspring"):
                        inner[3]["together"] = True
                    elif inner[0] == "mui":
                        inner[4]["together"] = True
                return ("mtl_add", nt.val, inner, t.line)
            except _NotMotion:
                self.pos = save
        widgets = ("title", "label", "button", "field", "checkbox",
                   "slider", "image", "panel")
        pk = self.peek()
        pk2 = self.peek(1)
        maybe_widget = ((pk.kind == "NAME" and pk.val in widgets) or
                        (pk.kind == "KW" and pk.val == "button"))
        # widget-add vs list-append: scan this line for 'at' before 'to'
        is_widget = False
        if maybe_widget and pk2.kind in ("TEXT", "NAME"):
            j = self.pos + 2
            while j < len(self.toks):
                tk = self.toks[j]
                if tk.kind in ("NEWLINE", "EOF"):
                    break
                if tk.kind == "KW" and tk.val == "at":
                    is_widget = True
                    break
                if tk.kind == "KW" and tk.val == "to":
                    break
                j += 1
        if is_widget:
            widget = self.next().val
            nt = self.next()
            name_node = ("text", nt.val) if nt.kind == "TEXT" else ("name", nt.val)
            self.eat_kw("at", "before the position in 'add ...'")
            x = self.parse_add()
            self.eat_sym(",", "between x and y in 'add ... at x, y'")
            y = self.parse_add()
            w = h = None
            if self.at_kw("with"):
                self.next()
                kt = self.next()
                if not (kt.kind == "NAME" and kt.val == "width"):
                    raise DepError("after 'with' write 'width'", kt.line)
                w = self.parse_add()
                if self.at_kw("and"):
                    self.next()
                    kt2 = self.next()
                    if not (kt2.kind == "NAME" and kt2.val == "height"):
                        raise DepError("after 'and' write 'height'", kt2.line)
                    h = self.parse_add()
            return ("addwidget", widget, name_node, x, y, w, h, t.line)
        expr = self.parse_add()
        self.eat_kw("to", "in 'add ... to <list>'")
        target = self.parse_target()
        return ("append", target, expr, t.line)

    def parse_remove(self):
        t = self.eat_kw("remove")
        if self.at_kw("item"):
            self.next()
            idx = self.parse_expr()
            self.eat_kw("from", "in 'remove item ... from ...'")
            target = self.parse_target()
            return ("remove", target, idx, True, t.line)
        expr = self.parse_expr()
        self.eat_kw("from", "in 'remove ... from ...'")
        target = self.parse_target()
        return ("remove", target, expr, False, t.line)

    # ================= motion kit (v1.4.0) =================

    def parse_motion_stmt(self, word):
        """Statement-head dispatch for animation sentences.  The leading word
        is consumed here; before the sentence shape is confirmed we raise
        _NotMotion so the line can fall back to a normal call statement."""
        if word == "clear":
            t = self.next()
            self.next()                       # the word 'particles'
            return ("mpart", "clear", None, t.line)
        if word == "move":
            return self._parse_move(False)
        if word == "spring":
            return self._parse_move(True)
        if word == "stop":
            return self._parse_stop()
        if word == "play":
            return self._parse_play()
        if word in ("pause", "resume"):
            return self._parse_tl_pause_resume(word)
        if word == "advance":
            return self._parse_advance()
        if word in ("burst", "rain", "snow"):
            return self._parse_particles(word)
        if word == "shake":
            if self._at_word(1, "screen"):
                return self._parse_shake()
            return self._parse_ui("shake")
        if word == "flash":
            return self._parse_flash()
        if word == "fade":
            return self._parse_fade()
        if word == "zoom":
            return self._parse_zoom()
        if word == "reset":
            return self._parse_reset()
        return self._parse_ui(word)           # pop, slide, glide, bump, wiggle

    def parse_timeline_item(self, word):
        """The inside of `add <item> to timeline "name"`."""
        if word in ("move", "spring"):
            return self._parse_move(word == "spring", in_tl=True)
        if word == "wait":
            t = self.next()
            dur = self.parse_add()
            ms = self._motion_unit()
            return ("mwait", dur, ms, t.line)
        return self._parse_ui(word, in_tl=True)

    def _motion_unit(self):
        """Optional time unit after a duration/delay. True = milliseconds."""
        if self._at_word(0, *MOTION_DUR_UNITS):
            t = self.next()
            return t.val in ("millisecond", "milliseconds", "ms")
        return False

    def _motion_feel_word(self):
        t = self.next()
        if t.kind == "TEXT":
            return t.val
        if t.kind in ("KW", "NAME"):
            return t.val
        raise DepError("after 'feeling' write a feeling word (bouncy, springy, "
                       "snappy, smooth, quick...) or a quoted curve name like "
                       "\"ease-out-bounce\"", t.line)

    def _motion_color(self):
        t = self.next()
        if t.kind == "TEXT":
            return ("text", t.val)
        if t.kind in ("KW", "NAME"):
            return ("text", t.val)            # single-word color
        raise DepError("write a color word (white, black, gold...) or a "
                       "quoted color like \"night blue\"", t.line)

    def _motion_end(self, line, what):
        if not self.end_of_stmt():
            t = self.peek()
            raise DepError(f"unexpected '{self._show(t)}' after {what}", t.line)

    def _parse_move(self, spring, in_tl=False):
        t = self.next()                       # move / spring
        line = t.line
        if self.peek().kind != "NAME":
            raise _NotMotion()
        target = self.parse_target()
        if not self._at_word(0, "toward"):
            raise _NotMotion()
        self.next()
        self._motion_stop = MOTION_VALUE_STOP
        try:
            value = self.parse_add()
        finally:
            self._motion_stop = set()
        opts = {"feel": None, "dur": None, "dur_ms": False, "from_expr": None,
                "delay": None, "delay_ms": False, "forever": False,
                "repeat": None, "pingpong": False, "together": False,
                "speed": None, "wobble": None, "stiffness": None,
                "damping": None}
        stop_next = {"with", "speed", "wobble", "stiffness", "damping",
                     "lasting", "feeling", "waiting", "starting",
                     "reversing", "repeating", "together"}
        after_and = False
        while True:
            if self._at_word(0, "and") and self._at_word(1, *stop_next):
                self.next()
                after_and = True
                continue
            if self._at_word(0, "lasting"):
                self.next()
                opts["dur"] = self.parse_add()
                opts["dur_ms"] = self._motion_unit()
            elif self._at_word(0, "feeling"):
                self.next()
                opts["feel"] = self._motion_feel_word()
            elif self._at_word(0, "starting"):
                self.next()
                if not self._at_word(0, "from"):
                    raise DepError("after 'starting' write 'from'",
                                   self.peek().line)
                self.next()
                opts["from_expr"] = self.parse_add()
            elif self._at_word(0, "waiting"):
                self.next()
                opts["delay"] = self.parse_add()
                opts["delay_ms"] = self._motion_unit()
            elif self._at_word(0, "reversing"):
                self.next()
                opts["pingpong"] = True
            elif self._at_word(0, "repeating"):
                self.next()
                if self.at_kw("forever"):
                    self.next()
                    opts["forever"] = True
                else:
                    opts["repeat"] = self.parse_add()
                    if not self._at_word(0, "times"):
                        raise DepError("after 'repeating 3' write 'times' "
                                       "(or write 'repeating forever')",
                                       self.peek().line)
                    self.next()
            elif self._at_word(0, "together"):
                self.next()
                opts["together"] = True
            elif spring and (self._at_word(0, "with") or
                             (after_and and self._at_word(0, "speed", "wobble",
                                                          "stiffness", "damping"))):
                if self._at_word(0, "with"):
                    self.next()
                after_and = False
                kt = self.next()
                if not (kt.kind in ("KW", "NAME") and
                        kt.val in ("speed", "wobble", "stiffness", "damping")):
                    raise DepError("after 'with' write 'speed', 'wobble', "
                                   "'stiffness' or 'damping'", kt.line)
                opts[kt.val] = self.parse_add()
            else:
                after_and = False
                break
        if not in_tl and opts["together"]:
            raise DepError("'together' only makes sense when adding steps to "
                           "a timeline", line)
        node = ("mspring" if spring else "mmove", target, value, opts, line)
        if not in_tl:
            self._motion_end(line, "the animation sentence")
        return node

    def _parse_ui(self, word, in_tl=False):
        t = self.next()
        line = t.line
        op_in_out = None
        if word in ("pop", "slide", "fade"):
            d = self.next()
            if not (d.kind in ("KW", "NAME") and d.val in ("in", "out")):
                raise _NotMotion()
            op_in_out = d.val
        base_op = "shake" if word == "wiggle" else word
        wt = self.peek()
        if not (wt.kind in ("NAME", "KW") and wt.val in MOTION_WIDGETS):
            raise _NotMotion()
        self.next()
        nt = self.next()
        if nt.kind != "TEXT":
            raise _NotMotion()
        widget, name = wt.val, nt.val
        opts = {"dur": None, "dur_ms": False, "feel": None, "dir": None,
                "x": None, "y": None, "strength": None}
        if base_op == "slide":
            want = "from" if op_in_out == "in" else "to"
            kw = self.next()
            if not (kw.kind in ("KW", "NAME") and kw.val == want):
                raise DepError(f"after 'slide {op_in_out} ...' write "
                               f"'{want} \"left\"' (or \"right\", \"top\", "
                               f"\"bottom\")", kw.line)
            dt = self.next()
            if dt.kind != "TEXT":
                raise DepError("write the direction in quotes: \"left\", "
                               "\"right\", \"top\" or \"bottom\"", dt.line)
            opts["dir"] = dt.val
        elif base_op == "glide":
            if not self.at_kw("to"):
                raise DepError("after 'glide <widget> \"name\"' write "
                               "'to x, y'", self.peek().line)
            self.next()
            self._motion_stop = MOTION_VALUE_STOP
            try:
                opts["x"] = self.parse_add()
                self.eat_sym(",", "between x and y in 'glide ... to x, y'")
                opts["y"] = self.parse_add()
            finally:
                self._motion_stop = set()
        stop_next = {"lasting", "feeling", "with", "strength"}
        after_and = False
        while True:
            if self._at_word(0, "and") and self._at_word(1, *stop_next):
                self.next()
                after_and = True
                continue
            if self._at_word(0, "lasting"):
                self.next()
                opts["dur"] = self.parse_add()
                opts["dur_ms"] = self._motion_unit()
            elif self._at_word(0, "feeling"):
                self.next()
                opts["feel"] = self._motion_feel_word()
            elif base_op in ("shake", "wiggle") and (self._at_word(0, "with") or
                    (after_and and self._at_word(0, "strength"))):
                if self._at_word(0, "with"):
                    self.next()
                after_and = False
                kt = self.next()
                if not (kt.kind in ("KW", "NAME") and kt.val == "strength"):
                    raise DepError("after 'with' write 'strength'", kt.line)
                opts["strength"] = self.parse_add()
            else:
                after_and = False
                break
        op = {"pop": f"pop_{op_in_out}", "slide": f"slide_{op_in_out}",
              "fade": f"fade_{op_in_out}"}.get(base_op, base_op)
        node = ("mui", op, widget, name, opts, line)
        if not in_tl:
            self._motion_end(line, "the animation sentence")
        return node

    def _parse_shake(self):
        t = self.next()
        line = t.line
        self.next()                            # screen
        opts = {"strength": None, "dur": None, "dur_ms": False}
        while True:
            if self._at_word(0, "with"):
                self.next()
                kt = self.next()
                if not (kt.kind in ("KW", "NAME") and kt.val == "strength"):
                    raise DepError("after 'with' write 'strength'", kt.line)
                opts["strength"] = self.parse_add()
            elif self._at_word(0, "lasting"):
                self.next()
                opts["dur"] = self.parse_add()
                opts["dur_ms"] = self._motion_unit()
            else:
                break
        self._motion_end(line, "the shake")
        return ("mfx", "shake", opts, line)

    def _parse_flash(self):
        t = self.next()
        line = t.line
        opts = {"color": self._motion_color(), "dur": None, "dur_ms": False}
        while self._at_word(0, "lasting"):
            self.next()
            opts["dur"] = self.parse_add()
            opts["dur_ms"] = self._motion_unit()
        self._motion_end(line, "the flash")
        return ("mfx", "flash", opts, line)

    def _parse_fade(self):
        t = self.next()
        line = t.line
        d = self.next()
        if not (d.kind in ("KW", "NAME") and d.val in ("in", "out", "to", "from")):
            raise _NotMotion()
        if d.val in ("in", "out"):
            wt = self.peek()
            if not (wt.kind in ("NAME", "KW") and wt.val in MOTION_WIDGETS):
                raise _NotMotion()
            self.next()
            nt = self.next()
            if nt.kind != "TEXT":
                raise _NotMotion()
            opts = {"dur": None, "dur_ms": False, "feel": None}
            while True:
                if self._at_word(0, "lasting"):
                    self.next()
                    opts["dur"] = self.parse_add()
                    opts["dur_ms"] = self._motion_unit()
                elif self._at_word(0, "feeling"):
                    self.next()
                    opts["feel"] = self._motion_feel_word()
                else:
                    break
            node = ("mui", f"fade_{d.val}", wt.val, nt.val, opts, line)
            self._motion_end(line, "the fade")
            return node
        opts = {"color": self._motion_color(), "dur": None, "dur_ms": False}
        while self._at_word(0, "lasting"):
            self.next()
            opts["dur"] = self.parse_add()
            opts["dur_ms"] = self._motion_unit()
        self._motion_end(line, "the fade")
        return ("mfx", "fadeto" if d.val == "to" else "fadefrom", opts, line)

    def _parse_zoom(self):
        t = self.next()
        line = t.line
        if not self._at_word(0, "screen"):
            raise _NotMotion()
        self.next()
        if not self.at_kw("to"):
            raise DepError("after 'zoom screen' write 'to 1.5'", self.peek().line)
        self.next()
        opts = {"target": self.parse_add(), "dur": None, "dur_ms": False,
                "feel": None}
        while True:
            if self._at_word(0, "lasting"):
                self.next()
                opts["dur"] = self.parse_add()
                opts["dur_ms"] = self._motion_unit()
            elif self._at_word(0, "feeling"):
                self.next()
                opts["feel"] = self._motion_feel_word()
            else:
                break
        self._motion_end(line, "the zoom")
        return ("mfx", "zoom", opts, line)

    def _parse_reset(self):
        t = self.next()
        line = t.line
        if not self._at_word(0, "screen"):
            raise _NotMotion()
        self.next()
        self._motion_end(line, "'reset screen'")
        return ("mfx", "reset", {}, line)

    def _parse_part_opts(self):
        opts = {"color": None, "speed": None, "size": None, "life": None}
        keys = ("color", "speed", "size", "life")
        while True:
            if self._at_word(0, "with"):
                self.next()
            elif self._at_word(0, "and") and self._at_word(1, *keys):
                self.next()
            else:
                break
            kt = self.next()
            if not (kt.kind in ("KW", "NAME") and kt.val in keys):
                raise DepError("after 'with' write 'color', 'speed', 'size' "
                               "or 'life'", kt.line)
            if kt.val == "color":
                opts["color"] = self._motion_color()
            elif kt.val == "life":
                opts["life"] = self.parse_add()
                self._motion_unit()
            else:
                opts[kt.val] = self.parse_add()
        return opts

    def _parse_particles(self, word):
        t = self.next()
        line = t.line
        if word == "burst":
            n = self.parse_add()
            kt = self.next()
            if not (kt.kind in ("KW", "NAME") and kt.val in MOTION_PART_KINDS):
                raise _NotMotion()
            kind = kt.val
            if not self.at_kw("at"):
                raise DepError("after 'burst 30 sparks' write 'at x, y'",
                               self.peek().line)
            self.next()
            x = self.parse_add()
            self.eat_sym(",", "between x and y in 'burst ... at x, y'")
            y = self.parse_add()
            opts = self._parse_part_opts()
            self._motion_end(line, "the burst")
            return ("mpart", "burst", (n, kind, x, y, opts), line)
        n = self.parse_add()
        opts = self._parse_part_opts()
        self._motion_end(line, f"the {word}")
        return ("mpart", word, (n, opts), line)

    def _parse_stop(self):
        t = self.next()
        line = t.line
        if self._at_word(0, "moving"):
            self.next()
            target = self.parse_target()
            self._motion_end(line, "'stop moving'")
            return ("mstop", target, line)
        if self.at_kw("every"):
            self.next()
            if not self._at_word(0, "animation", "animations"):
                raise DepError("after 'stop every' write 'animation'",
                               self.peek().line)
            self.next()
            return ("mstop", None, line)
        if self._at_word(0, "timeline"):
            self.next()
            nt = self.next()
            if nt.kind != "TEXT":
                raise DepError("after 'timeline' write its name in quotes",
                               nt.line)
            return ("mtl_stop", nt.val, line)
        raise _NotMotion()

    def _parse_play(self):
        t = self.next()
        line = t.line
        if not self._at_word(0, "timeline"):
            raise _NotMotion()
        self.next()
        nt = self.next()
        if nt.kind != "TEXT":
            raise DepError("after 'timeline' write its name in quotes", nt.line)
        forever = False
        repeat = None
        if self._at_word(0, "repeating"):
            self.next()
            if self.at_kw("forever"):
                self.next()
                forever = True
            else:
                repeat = self.parse_add()
                if not self._at_word(0, "times"):
                    raise DepError("after 'repeating 3' write 'times' (or "
                                   "write 'repeating forever')", self.peek().line)
                self.next()
        self._motion_end(line, "'play timeline'")
        return ("mtl_play", nt.val, repeat, forever, line)

    def _parse_tl_pause_resume(self, word):
        t = self.next()
        line = t.line
        if not self._at_word(0, "timeline"):
            raise _NotMotion()
        self.next()
        nt = self.next()
        if nt.kind != "TEXT":
            raise DepError("after 'timeline' write its name in quotes", nt.line)
        return ("mtl_pause" if word == "pause" else "mtl_resume", nt.val, line)

    def _parse_advance(self):
        t = self.next()
        line = t.line
        e = self.parse_add()
        ms = self._motion_unit()
        self._motion_end(line, "'advance'")
        return ("madvance", e, ms, line)


    def parse_callstmt(self):
        t = self.next()
        name = t.val
        args = []
        # 'f()' / 'f(x, y)' as a statement: when the matching ')' ends the
        # line, read a parenthesised argument list.  (Without this, 'ping()'
        # parsed as ping(ping()) -- a bogus argument that double-called.)
        if self.at_sym("(") and self._paren_call_stmt():
            self.next()                       # consume '('
            self.skip_newlines()
            while not self.at_sym(")"):
                args.append(self.parse_expr())
                if self.at_sym(","):
                    self.next()
                    self.skip_newlines()
                elif self.at_sym(")"):
                    break
                else:
                    raise DepError("expected ',' or ')' in call",
                                   self.peek().line)
            self.eat_sym(")", "to close call")
            return ("callstmt", name, args, t.line, None)
        if not self.end_of_stmt():
            args.append(self._parse_stmt_arg())
            while self.at_sym(",") or self.at_kw("and"):
                # 'image' pictures can end with frame/part/flipped/mirrored
                # clauses -- stop before the comma that introduces one.
                if name == "image" and self._at_image_clause(1):
                    break
                self.next()
                args.append(self._parse_stmt_arg())
        clauses = None
        if name == "image" and (self._at_image_clause(0) or
                                (self.at_sym(",") and self._at_image_clause(1))):
            clauses = self._parse_image_clauses()
        return ("callstmt", name, args, t.line, clauses)

    def _paren_call_stmt(self):
        """True when '(' ... matching ')' is followed by an end of statement,
        so 'name(...)' reads as a whole call statement."""
        depth = 0
        k = self.pos
        while k < len(self.toks):
            tk = self.toks[k]
            if tk.kind in ("NEWLINE", "EOF"):
                return False
            if tk.kind == "SYM" and tk.val in "([{":
                depth += 1
            elif tk.kind == "SYM" and tk.val in ")]}":
                depth -= 1
                if depth == 0:
                    break
            k += 1
        if depth != 0 or k >= len(self.toks) - 1:
            return k == len(self.toks) - 1 and depth == 0
        after = self.toks[k + 1]
        return after.kind in ("NEWLINE", "EOF") or \
            (after.kind == "KW" and after.val in ("end", "else"))

    def _at_image_clause(self, off):
        t = self.peek(off)
        if t.kind == "KW" and t.val == "frame":
            return True
        if t.kind == "NAME" and t.val in ("part", "flipped", "mirrored"):
            return True
        return False

    def _parse_image_num(self):
        """A number for a picture clause: a literal, a name, or (expr).
        Deliberately not a full expression, so 'frame pose of 2' does not
        read 'pose of 2' as the 'x of y' form."""
        t = self.peek()
        if t.kind == "NUM":
            self.next()
            return ("num", t.val)
        if t.kind == "SYM" and t.val == "(":
            self.next()
            e = self.parse_expr()
            self.eat_sym(")", "to close (")
            return e
        if t.kind == "NAME":
            self.next()
            return ("name", t.val)
        raise DepError(f"expected a number in a picture option but found "
                       f"{self._show(t)}", t.line)

    def _parse_image_clauses(self):
        cl = {}
        while True:
            if self.at_sym(","):
                self.next()
            t = self.peek()
            if t.kind == "KW" and t.val == "frame":
                self.next()
                idx = self._parse_image_num()
                self.eat_kw("of", "in 'frame N of M'")
                cnt = self._parse_image_num()
                if "part" in cl:
                    raise DepError("a picture can use 'frame' or 'part', not both",
                                   t.line)
                cl["frame"] = (idx, cnt)
            elif t.kind == "NAME" and t.val == "part":
                self.next()
                coords = [self._parse_image_num()]
                for _ in range(3):
                    self.eat_sym(",", "between 'part' numbers")
                    coords.append(self._parse_image_num())
                if "frame" in cl:
                    raise DepError("a picture can use 'frame' or 'part', not both",
                                   t.line)
                cl["part"] = tuple(coords)
            elif t.kind == "NAME" and t.val == "flipped":
                self.next()
                cl["flipv"] = True
            elif t.kind == "NAME" and t.val == "mirrored":
                self.next()
                cl["fliph"] = True
            else:
                raise DepError(f"expected a picture option (frame, part, flipped "
                               f"or mirrored) but found {self._show(t)}", t.line)
            if not (self.at_sym(",") and self._at_image_clause(1)):
                break
        return cl

    # ---- targets ----
    def parse_target(self):
        t = self.next()
        if t.kind != "NAME":
            raise DepError(f"expected a name after 'set'/'change' but found "
                           f"'{self._show(t)}'", t.line)
        node = ("tname", t.val)
        while True:
            if self.at_sym("."):
                self.next()
                f = self.next()
                if f.kind not in ("NAME", "KW"):
                    raise DepError(f"expected a field name after '.' but found "
                                   f"'{self._show(f)}'", f.line)
                node = ("tfield", node, f.val)
            elif self.at_sym("["):
                self.next()
                idx = self.parse_expr()
                self.eat_sym("]", "to close [")
                node = ("tindex", node, idx)
            else:
                return node

    def _target_str(self, node):
        if node[0] == "tname":
            return node[1]
        if node[0] == "tfield":
            return self._target_str(node[1]) + "." + node[2]
        return self._target_str(node[1]) + "[...]"

    # ---- expressions ----
    def parse_expr(self):
        return self.parse_or()

    def parse_or(self):
        a = self.parse_and()
        while self.at_kw("or"):
            self.next()
            b = self.parse_and()
            a = ("bin", "or", a, b)
        return a

    def parse_and(self):
        a = self.parse_not()
        while self.at_kw("and"):
            self.next()
            b = self.parse_not()
            a = ("bin", "and", a, b)
        return a

    def parse_not(self):
        if self.at_kw("not"):
            self.next()
            return ("un", "not", self.parse_not())
        return self.parse_cmp()

    def parse_cmp(self):
        a = self.parse_add()
        t = self.peek()
        if t.kind == "SYM" and t.val in (">", "<", ">=", "<="):
            self.next()
            b = self.parse_add()
            return ("cmp", t.val, a, b)
        if t.kind == "KW" and t.val == "is":
            self.next()
            neg = False
            if self.at_kw("not"):
                self.next()
                neg = True
            nt = self.peek()
            if nt.kind == "KW" and nt.val in ("more", "greater", "bigger"):
                self.next()
                self.eat_kw("than", f"after '{nt.val}'")
                b = self.parse_add()
                return ("cmp", ">" if not neg else "<=", a, b)
            if nt.kind == "KW" and nt.val in ("less", "fewer", "smaller"):
                self.next()
                self.eat_kw("than", f"after '{nt.val}'")
                b = self.parse_add()
                return ("cmp", "<" if not neg else ">=", a, b)
            if nt.kind == "KW" and nt.val == "at":
                self.next()
                lt = self.next()
                if lt.kind == "KW" and lt.val == "least":
                    b = self.parse_add()
                    return ("cmp", ">=" if not neg else "<", a, b)
                if lt.kind == "KW" and lt.val == "most":
                    b = self.parse_add()
                    return ("cmp", "<=" if not neg else ">", a, b)
                raise DepError("after 'at' write 'least' or 'most'", lt.line)
            b = self.parse_add()
            return ("isnot", a, b) if neg else ("is", a, b)
        if t.kind == "KW" and t.val == "has":
            self.next()
            if self.at_kw("not"):
                self.next()
                return ("hasnot", a, self.parse_add())
            return ("has", a, self.parse_add())
        if t.kind == "NAME" and t.val == "hits":
            self.next()
            return ("hits", a, self.parse_add())
        return a

    def parse_add(self):
        a = self.parse_mul()
        while self.at_sym("+") or self.at_sym("-"):
            op = self.next().val
            b = self.parse_mul()
            a = ("bin", op, a, b)
        return a

    def parse_mul(self):
        a = self.parse_unary()
        while self.at_sym("*") or self.at_sym("/") or self.at_sym("%"):
            op = self.next().val
            b = self.parse_unary()
            a = ("bin", op, a, b)
        return a

    def parse_unary(self):
        if self.at_sym("-"):
            self.next()
            return ("un", "neg", self.parse_unary())
        return self.parse_postfix()

    def parse_postfix(self):
        node = self.parse_primary()
        while True:
            if self.at_sym("."):
                self.next()
                f = self.next()
                if f.kind not in ("NAME", "KW"):
                    raise DepError(f"expected a field name after '.' but found "
                                   f"'{self._show(f)}'", f.line)
                node = ("field", node, f.val)
            elif self.at_sym("["):
                self.next()
                idx = self.parse_expr()
                self.eat_sym("]", "to close [")
                node = ("index", node, idx)
            else:
                return node

    def parse_primary(self):
        t = self.peek()
        if t.kind == "NUM":
            self.next()
            return ("num", t.val)
        if t.kind == "TEXT":
            self.next()
            return ("text", t.val)
        if t.kind == "SYM" and t.val == "(":
            self.next()
            e = self.parse_expr()
            self.eat_sym(")", "to close (")
            return e
        if t.kind == "SYM" and t.val == "[":
            self.next()
            items = []
            self.skip_newlines()
            while not self.at_sym("]"):
                items.append(self.parse_expr())
                if self.at_sym(","):
                    self.next()
                    self.skip_newlines()
                elif self.at_sym("]"):
                    break
                else:
                    raise DepError("expected ',' or ']' in list", self.peek().line)
            self.eat_sym("]", "to close list")
            return ("list", items)
        if t.kind == "SYM" and t.val == "{":
            self.next()
            pairs = []
            self.skip_newlines()
            while not self.at_sym("}"):
                kt = self.next()
                if kt.kind in ("NAME", "KW"):
                    key = ("text", kt.val)
                elif kt.kind in ("TEXT", "NUM"):
                    key = ("text" if kt.kind == "TEXT" else "num", kt.val)
                else:
                    raise DepError(f"expected a key name in map but found "
                                   f"'{self._show(kt)}'", kt.line)
                self.eat_sym(":", "after the key in a map")
                val = self.parse_expr()
                pairs.append((key, val))
                if self.at_sym(","):
                    self.next()
                    self.skip_newlines()
                elif self.at_sym("}"):
                    break
                else:
                    raise DepError("expected ',' or '}' in map", self.peek().line)
            self.eat_sym("}", "to close map")
            return ("map", pairs)
        if t.kind == "KW":
            if t.val in ("yes", "true"):
                self.next()
                return ("bool", 1)
            if t.val in ("no", "false"):
                self.next()
                return ("bool", 0)
            if t.val == "nothing":
                self.next()
                return ("nothing",)
            # a keyword being used as a function name: add(2, 3) or add 2, 3
            if (self.peek(1).kind == "SYM" and self.peek(1).val == "(") or \
               (t.val in BARE_CALL_KW and self._starts_bare_arg_at(1)):
                self.next()
                return self.parse_call_tail(t.val, t.line)
        if t.kind == "NAME":
            self.next()
            return self.parse_call_tail(t.val, t.line)
        raise DepError(f"unexpected {self._show(t)} in an expression", t.line)

    def _starts_neg_value(self):
        """'-' directly followed by something that starts a value: the start
        of a negative argument like the -5 in `abs -5`."""
        t = self.peek()
        if not (t.kind == "SYM" and t.val == "-"):
            return False
        nt = self.peek(1)
        if nt.kind in ("NUM", "NAME"):
            return True
        if nt.kind == "KW" and nt.val in ("yes", "no", "true", "false", "nothing"):
            return True
        if nt.kind == "SYM" and nt.val == "(":
            return True
        return False

    def parse_call_tail(self, name, line):
        """Parse the rest of a call after its name (bare or parenthesised)."""
        if self.at_sym("("):
            self.next()
            args = []
            self.skip_newlines()
            while not self.at_sym(")"):
                args.append(self.parse_expr())
                if self.at_sym(","):
                    self.next()
                    self.skip_newlines()
                elif self.at_sym(")"):
                    break
                else:
                    raise DepError("expected ',' or ')' in call",
                                   self.peek().line)
            self.eat_sym(")", "to close call")
            return ("call", name, args, line)
        if self.at_kw("of"):
            self.next()
            operand = self.parse_postfix()
            return ("call", name, [operand], line)
        if self._starts_bare_arg() or \
                (name in NEG_ARG_BUILTINS and self._starts_neg_value()):
            # 'hits' after a value is the collision infix, not a call argument
            nt = self.peek()
            if nt.kind == "NAME" and nt.val == "hits":
                return ("name", name)
            args = [self.parse_add()]
            # multi-arg builtins keep their own commas even inside a
            # statement's argument list, so `print min 3, 9` is min(3, 9)
            # and not min(3) followed by a second print argument
            while self.at_sym(",") and (not self._nested_arg or
                                        name in COMMA_ARG_BUILTINS):
                self.next()
                args.append(self.parse_add())
            return ("call", name, args, line)
        return ("name", name)

    def _starts_bare_arg(self):
        t = self.peek()
        if t.kind in ("KW", "NAME") and t.val in self._motion_stop:
            return False
        if t.kind in ("TEXT", "NUM", "NAME"):
            return True
        if t.kind == "KW" and t.val in ("yes", "no", "true", "false", "nothing"):
            return True
        if t.kind == "SYM" and t.val == "(":
            return True
        return False

    def _starts_bare_arg_at(self, off):
        t = self.peek(off)
        if t.kind in ("KW", "NAME") and t.val in self._motion_stop:
            return False
        if t.kind in ("TEXT", "NUM", "NAME"):
            return True
        if t.kind == "KW" and t.val in ("yes", "no", "true", "false", "nothing"):
            return True
        if t.kind == "SYM" and t.val == "(":
            return True
        return False


def parse(src):
    return Parser(tokenize(src)).parse_program()
